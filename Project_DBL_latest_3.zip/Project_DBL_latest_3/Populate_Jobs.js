const oracledb = require("oracledb");
const jobData = require("./Jobs_Info");



async function populateJobsTable() {
  const connection = await oracledb.getConnection({
    user: "JOBATHON",
    password: "12345",
    connectString: "localhost/orclpdb",
  });


  try {
    const insertQuery = `
      INSERT INTO "Jobs" ("JobID", "Title", "Salary", "Category")
      VALUES (:jobID, :title, :salary, :category)
    `;

    for (const job of jobData) {
      const bindParams = {
        jobID: job.JobID,
        title: job.Title,
        salary: job.Salary,
        category: job.Category
      };

      await connection.execute(insertQuery, bindParams, { autoCommit: true });
      console.log(`Inserted job with JobID ${job.JobID}`);
    }
  } catch (error) {
    console.error("Error inserting jobs:", error);
  } finally {
    await connection.close();
  }
}

populateJobsTable();
