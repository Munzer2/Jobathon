document.addEventListener('DOMContentLoaded', () => {

    async function fetchEmployersForJob(jobID) {
        try {
            const response = await fetch(`/fetchEmployersForJob/${jobID}`);
            if (response.ok) {
                const employers = await response.json();
                displayEmployers(employers);
            } else {
                console.error('Failed to fetch employers for the job');
            }
        } catch (error) {
            console.error('Error:', error);
        }
    }

    function displayEmployers(employers) {
        const employersList = document.getElementById('Employers-list');
        employersList.innerHTML = '';

        if (employers.length === 0) {
            employersList.innerHTML = '<li>No employers found for this job.</li>';
        } else {
            employers.forEach(async (employer) => {
                const company = await fetch(`/fetchCompany/${employer.ComID}`);
                const res = await company.json();
                const listItem = document.createElement('li');
                listItem.classList.add('employer-item');
                const employerInfo = document.createElement('div');
                employerInfo.classList.add('employer-info');
                employerInfo.innerHTML = `
                <div class="employer-info">
                <span class="employer-details">Name: ${employer.firstName} ${employer.lastName}</span>
                    <span class="employer-details">Phone: ${employer.Phone}</span>
                    <span class="employer-details">Country:${employer.Country}</span>
                    <span class="employer-details">Works at: ${res.Name}</span>
                </div>
                `;

                listItem.appendChild(employerInfo);

                employersList.appendChild(listItem);
            });
        }
    }

    window.addEventListener('load', () => {
        const jobID = document.body.getAttribute('data-job-ID');
        fetchEmployersForJob(jobID);
    });

}); 