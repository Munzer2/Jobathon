const oracledb = require("oracledb");

async function populatereviewsTable() {
    const connection = await oracledb.getConnection({
      user: "JOBATHON",
      password: "12345",
      connectString: "localhost/orclpdb",
    });
    const insertOffersQuery = `INSERT INTO "Review" ("ReviewerID", "ReviewedCompanyID", "Review") VALUES (:userID, :companyId, :review)`;
  
    try {
      const usersQuery = 'SELECT * FROM "User" WHERE "Type" IN (:employer, :worker)';
      const usersResult = await connection.execute(usersQuery, ['Employer', 'Worker']);
      const reviewRatings = [1, 2, 3, 4, 5];
  
      for (const user of usersResult.rows) { 
        const randomRating = reviewRatings[Math.floor(Math.random() * reviewRatings.length)];
        const insertReview = {
          userID: user[0],
          companyId: user[10], 
          review: randomRating,
        };
        await connection.execute(insertOffersQuery, insertReview);
      }
    } catch (error) {
      console.error("Error inserting reviews:", error);
    } finally {
        await connection.commit(); 
      await connection.close();
    }
  }

populatereviewsTable();
