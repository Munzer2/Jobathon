document.addEventListener("DOMContentLoaded", function (event) {

    const showNavbar = (toggleId, navId, bodyId, headerId) => {
        const toggle = document.getElementById(toggleId),
            nav = document.getElementById(navId),
            bodypd = document.getElementById(bodyId),
            headerpd = document.getElementById(headerId)


        // Validate that all variables exist
        if (toggle && nav && bodypd && headerpd) {
            toggle.addEventListener('click', () => {
                // show navbar
                nav.classList.toggle('show')
                // change icon
                toggle.classList.toggle('bx-x')
                // add padding to body
                bodypd.classList.toggle('body-pd')
                // add padding to header
                headerpd.classList.toggle('body-pd')
            })
        }
    }

    showNavbar('header-toggle', 'nav-bar', 'body-pd', 'header')

    /*===== LINK ACTIVE =====*/
    const linkColor = document.querySelectorAll('.nav_link')

    function colorLink() {
        if (linkColor) {
            linkColor.forEach(l => l.classList.remove('active'))
            this.classList.add('active')
        }
    }
    linkColor.forEach(l => l.addEventListener('click', colorLink))
});


document.addEventListener("DOMContentLoaded", function () {

    ///DashBoard: user details. 
    const loadDashboardContent = async () => {
        sectionIDs = ['similar-users-container', 'company-content', 'jobdetails-content', 'view-jobs-content', 'messages-content', 'fav-jobs'];
        hideSections(sectionIDs);
        const userID = document.body.getAttribute('data-user-ID');
        const dashboardContent = document.getElementById('dashboard-content');
        const age = document.body.getAttribute('data-user-age');
        const gender = document.body.getAttribute('data-user-gender');
        const Country = document.body.getAttribute('data-user-country');
        const phone = document.body.getAttribute('data-user-phone');
        const firstName = document.body.getAttribute('firstName');
        const lastName = document.body.getAttribute('lastName');
        const city = document.body.getAttribute('city');
        const ComID = document.body.getAttribute('data-user-ComID');
        const State = document.body.getAttribute('data-user-state');
        const Postal = document.body.getAttribute('data-user-postal');
        const Photo = document.body.getAttribute('data-user-Photo');
        let Type = document.body.getAttribute('data-user-Type');
        if (Type == 'Seeker') Type = 'Exploring';
        else if (Type == 'Worker') Type = 'Working';
        const hobbyres = await fetch(`/fetchHobbies/${userID}`);
        userHobbies = await hobbyres.json();

        const userInformationHTML = `
        <div class="user-photo">
            <img src="${Photo}">
        </div>
        <div class="user-info">
            <h1><strong>About ${firstName}</strong></h1>
            <p><strong>Name:</strong> ${firstName} ${lastName}</p>
            <p><strong>Age:</strong> ${age}</p>
            <p><strong>Gender:</strong> ${gender}</p>
            <p><strong>City:</strong> ${city}</p>
            <p><strong>Country:</strong> ${Country}</p>
            <p><strong>State:</strong> ${State}</p>
            <p><strong>Postal Code:</strong> ${Postal}</p>
            <p><strong>Phone:</strong> ${phone}</p>
            <p><strong>Status:</strong> ${Type}</p>
            <p><strong>Enjoys:</strong>${userHobbies}</p> 

            <div >
          <a href="/updateInfo" style="position: relative; bottom: 20px; left: 1000px;font-size: 24px;">
            <i class='bx bx-briefcase'></i> <span>Update profile</span>
            </a>
           </div>
        </div>

                `;
        dashboardContent.style.display = 'block';
        dashboardContent.innerHTML = userInformationHTML;
    };
    const dashboardLink = document.querySelector('.nav_link.active');
    if (dashboardLink) {
        dashboardLink.addEventListener('click', loadDashboardContent);
    }


    ///Company and Job details. 
    const loadCompanyDetails = async () => {
        try {
            sectionIDs = ['dashboard-content', 'similar-users-container', 'view-jobs-content', 'messages-content', 'fav-jobs'];
            hideSections(sectionIDs);
            const ComID = document.body.getAttribute('data-user-ComID');
            const type = document.body.getAttribute('data-user-type');
            const companycontent = document.getElementById('company-content');
            if (type == 'Seeker') {
                const details = `<p><strong>Not currently working. Explore jobs!</strong></p>`;
                companycontent.innerHTML = details;
            }
            else {
                const userID = document.body.getAttribute('data-user-ID');
                const res = await fetch(`/fetchJobDetails2/${userID}`);
                const jobData = await res.json();
                const response = await fetch(`/fetchCompany/${ComID}`);
                const companyData = await response.json();
                const companyDetailsHTML = `
                <div class="details-container">
                <div class="company-details">
                <h1><strong>Working at</strong></h1>
                <p></p> 
                    <p><strong>Name:</strong> ${companyData.Name}</p>
                    <p><strong>Main Branch: </strong>${companyData.Main_Branch}</p>
                    <p><strong>Location: </strong> ${companyData.Origin}</p>
                    <p><strong>ID: </strong> ${companyData.CompanyID} </p>
                    <p><strong>CEO: </strong> ${companyData.CEO} </p>
                    <p><strong>Industry: </strong> ${companyData.Industry} </p>
                </div>
                <div class ="job-details">
                    <p></p>
                    <h1><strong>Current Job</strong></h1>
                    <p><strong>Name:</strong>${jobData.Title}</p>
                    <p><strong>Salary :</strong>${jobData.Salary}</p>
                    <p><strong>Job ID:</strong> ${jobData.JobID}</p>
                </div>
                </div>
            `;
                companycontent.style.display = 'block';
                companycontent.innerHTML = companyDetailsHTML;
            }
        } catch (error) {
            console.error('Error fetching company details:', error);
        }
    };

    const companyDetailsLink = document.getElementById('company-details-link');
    if (companyDetailsLink) {
        companyDetailsLink.addEventListener('click', loadCompanyDetails);
    }

    ////Fetching similar user functionalities.
    let SimilarUsers = null;
    const fetchSimilarUsersData = async () => {
        const userID = document.body.getAttribute('data-user-ID');
        const res = await fetch(`/fetchSimilarUsers/${userID}`);
        SimilarUsers = await res.json();
    };

    const loadOthersLink = () => {
        sectionIDs = ['dashboard-content', 'company-content', 'jobdetails-content', 'view-jobs-content', 'messages-content', 'fav-jobs'];
        hideSections(sectionIDs);

        // Check if the data is already fetched
        if (SimilarUsers) {
            const similarUsersList = document.getElementById('similar-users-list');
            similarUsersList.innerHTML = '';
            SimilarUsers.forEach((user) => {
                const userListItem = document.createElement('li');
                userListItem.innerHTML = `
                    <img src="${user.Photo}" alt="User Photo">
                    <div>
                        <p class="user-info"><strong>First Name:</strong> ${user.firstName}</p>
                        <p class="user-info2"><strong>Last Name:</strong> ${user.lastName}</p>  
                        <p><strong>Phone:</strong> ${user.Phone}</p>
                        <p><strong>Gender:</strong> ${user.Gender}</p>
                        <p><strong>Country:</strong> ${user.Country} </p>
                    </div>
                `;
                similarUsersList.appendChild(userListItem);
            });

            const similarUsersContainer = document.getElementById('similar-users-container');
            similarUsersContainer.style.display = 'block';
        } else {
            fetchSimilarUsersData()
                .then(() => {
                    loadOthersLink();
                })
                .catch((error) => {
                    console.error('Error fetching similar users data:', error);
                });
        }
    };
    const otherdetails = document.getElementById('others-details-link');
    if (otherdetails) {
        otherdetails.addEventListener('click', loadOthersLink);
    }

    const searchInput = document.getElementById('searchInput');
    const similarUsersList = document.getElementById('similar-users-list');

    searchInput.addEventListener('input', () => {
        const searchTerm = searchInput.value.toLowerCase();
        const userItems = similarUsersList.querySelectorAll('li');

        userItems.forEach(userItem => {
            const userName = userItem.querySelector('.user-info').textContent.toLowerCase();
            const userName2 = userItem.querySelector('.user-info2').textContent.toLowerCase();
            if (userName.includes(searchTerm) || (userName2).includes(searchTerm)) {
                userItem.style.display = 'block';
            } else {
                userItem.style.display = 'none';
            }
        });
    });

    let allJobs = null;
    const fetchAllJobs = async () => {
        const res = await fetch(`/fetchAllJobs`);
        allJobs = await res.json();
    }

    const advancedSearchButton = document.getElementById('Advanced-Search');

    advancedSearchButton.addEventListener('click', () => {
        const userID = document.body.getAttribute('data-user-ID');
        window.location.href = `/advanced-search/${userID}`;
    });

    const loadAllJobs = async () => {
        sectionIDs = ['dashboard-content', 'company-content', 'jobdetails-content', 'similar-users-container', 'messages-content'];
        hideSections(sectionIDs);
        if (allJobs) {
            const JobHtml1 = document.getElementById('Jobs_List1');
            const JobHtml2 = document.getElementById('Jobs_List2');
            JobHtml1.innerHTML = '';
            JobHtml2.innerHTML = '';
            let cnt = 0;
            allJobs.forEach((Job) => {
                const JobListItem = document.createElement('li');
                JobListItem.classList.add('job-list-item');

                JobListItem.innerHTML = `
                <div class="job-info">
                    <h3><i class="fa fa-briefcase job-icon"></i>${Job.Title}</h3>
                    <p class="job-salary"><strong>Salary:</strong> $${Job.Salary}</p>
                    <p class ="job-category"><strong>Category:</strong>${Job.Category}</p>
                    <button class="add-interest-button" data-job-id="${Job.JobID}"><i class="fa fa-plus"></i></button>
                </div>
            `;

                if (cnt % 2 === 0) {
                    JobHtml1.appendChild(JobListItem);
                } else {
                    JobHtml2.appendChild(JobListItem);
                }
                cnt++;
            });

            const viewJobs = document.getElementById('view-jobs-content');
            viewJobs.style.display = 'block';
            const addInterestButtons = document.querySelectorAll('.add-interest-button');
            addInterestButtons.forEach(button => {
                button.addEventListener('click', async () => {
                    const jobId = button.getAttribute('data-job-id');
                    const userId = document.body.getAttribute('data-user-ID');
                    ///for debugging.
                    // console.log(JSON.stringify({
                    //     ID_of_User: userId,
                    //     JobID: jobId
                    // }));

                    try {
                        const response = await fetch('/addToInterests', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                ID_of_User: userId,
                                Wanted_JobID: jobId
                            })
                        });

                        if (response.ok) {
                            alert('Job added to interests successfully!');
                        } else {
                            alert('Failed to add job to interests.');
                        }
                    } catch (error) {
                        console.error('Error:', error);
                        alert('An error occurred while adding job to interests.');
                    }
                });
            });
        }
        else {
            fetchAllJobs()
                .then(() => {
                    loadAllJobs();
                })
                .catch((error) => {
                    console.error('Error fetching all jobs data:', error);
                });
        }
    };

    const viewJobsSection = document.getElementById('All-Jobs-link');
    if (viewJobsSection) {
        viewJobsSection.addEventListener('click', loadAllJobs);
    }



    // JavaScript for the user list dialog and chat interface
    const messagesLink = document.getElementById('messages-link');
    const messagesContent = document.getElementById('messages-content');

    messagesLink.addEventListener('click', () => {
        sectionIDs = ['dashboard-content', 'company-content', 'jobdetails-content', 'similar-users-container', 'view-jobs-content', 'fav-jobs'];
        hideSections(sectionIDs);
        if (messagesContent.style.display === 'none') {
            messagesContent.style.display = 'block';
        }
    });


    ////This section contains messaging functionalities.
    const userListDialog = document.getElementById('user-list-dialog');
    const userList = document.getElementById('user-list');
    const chatContainer = document.getElementById('Private-chat');
    const messageList = document.getElementById('Private-message-list');
    const messageInput = document.getElementById('Private-message-input');
    const closeChatButton = document.getElementById('close-chat');
    const openUserListButton = document.getElementById('open-user-list-button');
    const closeUserListButton = document.getElementById('close-user-list-dialog');
    let firstName = null;
    let selectedUserId = null;
    const socket = io('http://localhost:3000');


    function showChat() {
        chatContainer.style.display = 'block';
        openUserListButton.style.display = 'none';
    }

    async function addmessage(message, isYourMessage) {
        const messageItem = document.createElement('li');
        if (isYourMessage) {
            messageItem.textContent = message;
            messageItem.classList.add('your-message');
        }
        else {
            messageItem.classList.add('sender-message');
            messageItem.textContent = firstName + ': ' + message;
        }
        messageList.appendChild(messageItem);

        messageList.scrollTop = messageList.scrollHeight;
    }
    async function addmessage2(message, isYourMessage) {
        const messageItem = document.createElement('li');
        if (isYourMessage) {
            messageItem.textContent = 'You: ' + message;
            messageItem.classList.add('your-message');
        }
        else {
            messageItem.classList.add('sender-message');
            messageItem.textContent = firstName + ': ' + message;
        }
        messageList.appendChild(messageItem);

        messageList.scrollTop = messageList.scrollHeight;
    }

    ///for private part: 
    const sendButton2 = document.getElementById('Private-send-button');
    sendButton2.addEventListener('click', actionToHappen);
    messageInput.addEventListener('keydown', (event) => {
        if (event.key == 'Enter' && !event.shiftKey) {
            event.preventDefault();
            actionToHappen();
        }
    });
    function actionToHappen() {
        if (selectedUserId) {
            // sendPrivmessage(selectedUserId); 
            const message = messageInput.value.trim();
            if (message != '') {
                const senderID = document.body.getAttribute('data-user-ID');
                socket.emit('Storage', message);
                socket.emit('Private message', message, selectedUserId, senderID);
                messageInput.value = '';
            }
        }
    }

    closeChatButton.addEventListener('click', () => {
        chatContainer.style.display = 'none';
        openUserListButton.style.display = 'block';
    });

    // Function to open the user list dialog
    openUserListButton.addEventListener('click', async () => {
        const res = await fetch('/fetchAllEmployers');
        const ans = await res.json();

        userList.innerHTML = '';

        ans.forEach((user) => {
            const listItem = document.createElement('li');
            listItem.textContent = user.firstName + ' ' + user.lastName;
            listItem.setAttribute('data-user-ID', user.UserID);
            listItem.setAttribute('data-user-name', user.firstName);
            userList.appendChild(listItem);
        });
        userListDialog.style.display = 'block';
    });

    const searchUserInput = document.getElementById('search-user-input');

    searchUserInput.addEventListener('input', () => {
        const searchTerm = searchUserInput.value.trim().toLowerCase();
        const userItems = document.querySelectorAll('#user-list li');

        userItems.forEach((userItem) => {
            const userName = userItem.textContent.toLowerCase();
            if (userName.includes(searchTerm)) {
                userItem.style.display = 'block';
            } else {
                userItem.style.display = 'none';
            }
        });
    });

    closeUserListButton.addEventListener('click', async () => {
        userListDialog.style.display = 'none';
    });

    userList.addEventListener('click', async (event) => {
        if (event.target.tagName === 'LI') {
            firstName = event.target.getAttribute('data-user-name');
            initiateChat(event.target.getAttribute('data-user-ID'));
            userListDialog.style.display = 'none';
        }
    });

    async function initiateChat(UserID) {
        selectedUserId = UserID;
        showChat();
        messageList.innerHTML = '';
        ///Now first show previous chats between user and selected_User. 
        const currentUserId = document.body.getAttribute('data-user-ID');

        if (!firstName) {
            try {
                const response = await fetch(`/getfirstname/${selectedUserId}`);
                const data = await response.json();
                if (data.success) {
                    firstName = data.firstName;
                }
                else {
                    console.log('Error retrieving firstName');
                }
            }
            catch (error) {
                console.error(error);
            }
        }

        try {
            const response = await fetch(`/api/messages1?userID=${currentUserId}&targetUserID=${UserID}`);

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const data = await response.json();

            data.forEach((message) => {
                const isYourMessage = (message.Sender_ID == currentUserId);
                addmessage2(message.Message, isYourMessage);
            });
        } catch (error) {
            console.error('Error fetching past messages:', error);
        }
    }

    function setUser() {
        const userID = document.body.getAttribute('data-user-ID');
        socket.emit('set user', userID);
    }
    setUser();


    socket.on('Private message', async (message, targetuserID, senderID) => {
        // console.log('sender: ' + senderID);
        // console.log('target: ' + targetuserID);
        if (selectedUserId == null) {
            initiateChat(senderID);
        }
        else if (targetuserID == document.body.getAttribute('data-user-ID')) {
            addmessage(message, false);
        }
        if (chatContainer.style.display == 'none') {
            chatContainer.style.display = 'block';
        }
        if (openUserListButton.style.display == 'block') {
            openUserListButton.style.display = 'none';
        }
    });

    socket.on('Send to thyself', async (message) => {
        addmessage('You:  ' + message, true);
    });


    fetch('/api/messages')
        .then((response) => response.json())
        .then((data) => {
            const messageList = document.getElementById('Private-message-list');
            data.forEach((message) => {
                const messageItem = document.createElement('li');
                messageItem.textContent = message;
                messageList.appendChild(messageItem);
            });
        });


    const favJobs = document.getElementById('Favourite-Jobs-Link');
    favJobs.addEventListener('click', async () => {
        sectionIDs = ['dashboard-content', 'company-content', 'jobdetails-content', 'similar-users-container', 'view-jobs-content', 'messages-content'];
        hideSections(sectionIDs);
        const userID = document.body.getAttribute('data-user-ID');
        const favres = await fetch(`/fetchFavJobs/${userID}`);
        const favs = await favres.json();
        const fav_content = document.getElementById('fav-jobs');

        fav_content.innerHTML = '';

        if (favs && favs.length > 0) {
            const jobPromises = favs.map(async (job) => {
                const jobres = await fetch(`/fetchJobDetails3/${job.Wanted_JobID}`);
                const favJob = await jobres.json();

                const jobDiv = document.createElement('div');
                jobDiv.classList.add('fav-job-item');

                jobDiv.innerHTML = `
                    <h2>${favJob[0].Title}</h2>
                    <p>Salary: $${favJob[0].Salary}</p>
                    <p>Category: ${favJob[0].Category}</p>
                    <div class="action-buttons">
                        <button class="apply-button" data-job-id ='${favJob[0].JobID}'>Apply</button>
                        <i class="fa fa-trash delete-button" data-job-id='${favJob[0].JobID}'></i>
                    </div>
                `;

                fav_content.appendChild(jobDiv);
            });
            await Promise.all(jobPromises);

            fav_content.style.display = 'block';
        } else {
            const jobDiv = document.createElement('div');
            jobDiv.classList.add('fav-job-item');
            jobDiv.innerHTML = `<p><strong>Nothing to show!</strong></p>`;
            fav_content.appendChild(jobDiv);
            fav_content.style.display = 'block';
        }
    });

    const fav_container = document.getElementById('fav-jobs'); 

    fav_container.addEventListener('click', async (event) => { 
        const target = event.target;
        if (target.classList.contains('.delete-button') || target.closest('.delete-button')) { 
            const jobID = event.target.getAttribute('data-job-id');
            const userID = document.body.getAttribute('data-user-ID'); 
            try {
                const response = await fetch(`/deleteJobOfInterest?userID=${userID}&jobID=${jobID}`);
    
                if (response.ok) {
                    event.target.parentElement.parentElement.remove();
                    alert('Job deleted from interests successfully.');
                } else {
                    alert('Failed to delete job from interests.');
                }
            } catch (error) {
                console.error('Error:', error);
                alert('An error occurred while deleting the job from interests.');
            }
        }
    });


    fav_container.addEventListener('click', async(event)=>{
        if(event.target.classList.contains('apply-button')){
            const jobID = event.target.getAttribute('data-job-id');
            console.log(jobID); 
            window.location.href = `/ApplyForjobs?jobID=${jobID}`;
        }
    })
    

    function hideSections(sectionIds) {
        sectionIds.forEach(id => {
            const section = document.getElementById(id);
            if (section) {
                section.style.display = 'none';
            }
        });
        const welcome = document.getElementById('Welcome');
        welcome.style.display = "none";
    }


});

