document.addEventListener('DOMContentLoaded', () => {

    async function fetchEmployersForJob(jobID) {
        try {
            const response = await fetch(`/fetchEmployersForJob/${jobID}`);
            if (response.ok) {
                const employers = await response.json();
                displayEmployers(employers);
            } else {
                console.error('Failed to fetch employers for the job');
            }
        } catch (error) {
            console.error('Error:', error);
        }
    }

    function displayEmployers(employers) {
        const employersList = document.getElementById('Employers-list');
        employersList.innerHTML = '';

        if (employers.length === 0) {
            employersList.innerHTML = '<li>No employers found for this job.</li>';
        } else {
            employers.forEach((employer) => {
                const listItem = document.createElement('li');
                listItem.classList.add('employer-item');
                listItem.innerHTML = `
                <div class="employer-info">
                    <span>Name: ${employer.firstName} ${employer.lastName}</span>
                    <span>Phone: ${employer.Phone}</span>
                    <span>Country: ${employer.Country}</span>
                </div>
            `;
                employersList.appendChild(listItem);
            });
        }
    }

    window.addEventListener('load', () => {
        const jobID = document.body.getAttribute('data-job-ID');
        fetchEmployersForJob(jobID);
    });

}); 