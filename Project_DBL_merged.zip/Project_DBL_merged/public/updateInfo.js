document.addEventListener('DOMContentLoaded', async () => {

    let UserID='';  
    let firstName = '';
    let lastName = '';
    let City = '';
    let Postal ='';
    let State ='';
    let Country ='';
    let Age = 0;
    let Gender ='';
    let Phone = '';
    let ComID ='';
    let CEO_Of_Company='';
    let Type = '';
    let Photo = '';
    let ComName ='';
    let ComMainBranch='';
    let ComIndustry='';
    let ComOrigin='';
    let JobTitle='';
    let JobSalary='';

    

    const response = await fetch(`/getAdnan`);
    const data = await response.json();
 

    
    


      
       

       try{

        const nextButton1 = document.getElementById('next');
        nextButton1.addEventListener('click', async (event) => {
            event.preventDefault();
    
    
            Gender = document.getElementById('gender').value;
            Age = document.getElementById('age').value; 
            firstName = document.getElementById('firstname').value; 
            lastName = document.getElementById('lastname').value;
            Type = document.getElementById('type').value; 
            Phone = document.getElementById('phone').value;
            ComName = document.getElementById('company').value;
            if(Gender===''){
               Gender =data.Gender
            }
            if(Age==0){
                Age=data.age;
            }
            if(firstName===''){
                firstName=data.firstName;
            } 
            if(lastName===''){
                lastName=data.lastName;
            }
            if(Type===''){
                Type=data.Type;
            }
            if(Phone===''){
                Phone=data.Phone;
            }
            if(ComName===''){
                ComName=data.ComName;
            }
    

            console.log(ComName);
            // const response1 = await fetch(`/changeFlagAdnan?firstname=${firstName}&lastname=${lastName}&
            // age=${Age}&gender=${Gender}&type=${Type}&phone=${Phone}`);
            // console.log(767697);
            // const data1 = await response1.json();
            if((Type.toUpperCase()==='Worker'.toUpperCase()||Type.toUpperCase()==='Employer'.toUpperCase())){
                  if(ComName==null){
                    alert('Please Enter Company Name to Proceed');
                  }
                  else{

                    const responseCom = await fetch(`/getComInfo?ComName=${ComName}`);
                    const dataCom = await responseCom.json();
                    if(!dataCom.success){
                        alert('Enter a valid Company Name');
                    }
                    else{

                       ComName=dataCom.user.Name;
                       

                window.location.href = `/changeFlag/${firstName}/${lastName}/${Age}/${Gender}/${Type}/${Phone}/${ComName}`; 
                    }
                    
    

                  }
                  
            }else{

                

                window.location.href = `/changeFlag/${firstName}/${lastName}/${Age}/${Gender}/${Type}/${Phone}/${ComName}`; 

            }
            
            
    
           
        
    
    
    
    
    
            
           });

         
       }catch(error){
        console.log(error)
       }

      

       try{

        const nextButton2 = document.getElementById('next2');
        nextButton2.addEventListener('click', async (event) => {
            event.preventDefault();
            console.log(nextButton2);
    
    
            City = document.getElementById('city').value;
            Postal = document.getElementById('postal').value; 
            State = document.getElementById('state').value; 
            Country = document.getElementById('country').value;
            if(City===''){
               City =data.City
            }
            if(Postal===''){
                Postal=data.Postal;
            }
            if(State===''){
                State=data.State;
            } 
            if(Country===''){
                Country=data.Country;
            }
            
            console.log(City,Postal,State,Country);
            
            // const response1 = await fetch(`/changeFlagAdnan?firstname=${firstName}&lastname=${lastName}&
            // age=${Age}&gender=${Gender}&type=${Type}&phone=${Phone}`);
            // console.log(767697);
            // const data1 = await response1.json();
            window.location.href = `/changeFlag/${State}/${Postal}/${City}/${Country}/${Country}/${Country}/${Country}`; 
    
           });

         
       }catch(error){
        console.log(error)
       }
       
       try{

        const updateButton = document.getElementById('update');
        updateButton.addEventListener('click', async (event) => {
            event.preventDefault();
           console.log('update');


           title = document.getElementById('title').value;
     

           if(data.Type.toUpperCase()==='user'.toUpperCase()){
 
            const response1 = await fetch(`/updateUpdate/Info`);        
            const data1 = await response1.json();
            if(data1.success){
                alert('Information Updated Successfully');
                window.location.href = `/user/${data.UserID}`; 
            }
            else{
                alert('Failed Update');
            }

          }
          else{


            if(title==='' && data.JobTitle==null){

                alert('Please Insert Title to proceed. ')
            }
            else{
                if(title===''){
                    title=data.JobTitle;
                }


                const response3 = await fetch(`/updateUpdate/Info`);        
                const data3 = await response3.json();
                if(data3.success){

                    const response2 = await fetch(`/updateInsert/Company/${title}`);        
                    const data2 = await response2.json();
                    if(data2.success){
                       alert('Sucessfully Profile Updated');
                       window.location.href = `/user/${data.UserID}`; 
                    }
                    else{
                        alert('Cannot Find the Job Title In your Company');
                    }

        
                }
                else{
                    alert('Failed Update');
                }
         

            }

            




          }


            
            
            // const response1 = await fetch(`/changeFlagAdnan?firstname=${firstName}&lastname=${lastName}&
            // age=${Age}&gender=${Gender}&type=${Type}&phone=${Phone}`);
            // console.log(767697);
            // const data1 = await response1.json();
           
    
           
        
    
    
    
    
    
            
           });

         
       }catch(error){
        console.log(error)
       }
      






});

