document.addEventListener("DOMContentLoaded", function (event) {

    const showNavbar = (toggleId, navId, bodyId, headerId) => {
        const toggle = document.getElementById(toggleId),
            nav = document.getElementById(navId),
            bodypd = document.getElementById(bodyId),
            headerpd = document.getElementById(headerId)


        // Validate that all variables exist
        if (toggle && nav && bodypd && headerpd) {
            toggle.addEventListener('click', () => {
                // show navbar
                nav.classList.toggle('show')
                // change icon
                toggle.classList.toggle('bx-x')
                // add padding to body
                bodypd.classList.toggle('body-pd')
                // add padding to header
                headerpd.classList.toggle('body-pd')
            })
        }
    }

    showNavbar('header-toggle', 'nav-bar', 'body-pd', 'header')

    /*===== LINK ACTIVE =====*/
    const linkColor = document.querySelectorAll('.nav_link')

    function colorLink() {
        if (linkColor) {
            linkColor.forEach(l => l.classList.remove('active'))
            this.classList.add('active')
        }
    }
    linkColor.forEach(l => l.addEventListener('click', colorLink))
});


document.addEventListener("DOMContentLoaded", function () {
    const loadDashboardContent = async () => {
        const dashboardContent = document.getElementById('dashboard-content');
        const age = document.body.getAttribute('data-user-age');
        const gender = document.body.getAttribute('data-user-gender');
        const Country = document.body.getAttribute('data-user-country');
        const phone = document.body.getAttribute('data-user-phone');
        const firstName = document.body.getAttribute('firstName');
        const lastName = document.body.getAttribute('lastName');
        const city = document.body.getAttribute('city'); 
        const ComID = document.body.getAttribute('data-user-ComID');

        const userInformationHTML = `
                    <div class="user-info">
                        <h2>User Information</h2>
                        <p><strong>Name:</strong> ${firstName} ${lastName}</p>
                        <p><strong>Age:</strong> ${age}</p>
                        <p><strong>Gender:</strong> ${gender}</p>
                        <p><strong>City:</strong> ${city}</p>
                        <p><strong>Country:</strong> ${Country}</p>
                        <p><strong>Phone:</strong> ${phone}</p>
                    </div>
                `;
        dashboardContent.innerHTML = userInformationHTML;
        dashboardContent.style.display = 'block';
    };
    const dashboardLink = document.querySelector('.nav_link.active');
    if (dashboardLink) {
        dashboardLink.addEventListener('click', loadDashboardContent);
    }

    const loadCompanyDetails = async () => {
        try {
            const ComID = document.body.getAttribute('data-user-ComID');
            const response = await fetch(`/fetchCompany/${ComID}`);
            const companyData = await response.json();
            console.log(companyData ) ; 

            const dashboardContent = document.getElementById('dashboard-content');
            const companyDetailsHTML = `
                <div class="company-details">
                    <h2>${companyData.CompanyName}</h2>
                    <p>${companyData.Description}</p>
                    <p>Location: ${companyData.Location}</p>
                </div>
            `;

            dashboardContent.innerHTML = companyDetailsHTML;
            dashboardContent.style.display = 'block';

        } catch (error) {
            console.error('Error fetching company details:', error);
        }
    };

    const companyDetailsLink = document.getElementById('company-details-link');
    if (companyDetailsLink) {
        companyDetailsLink.addEventListener('click', loadCompanyDetails);
    }
});

