const oracledb = require("oracledb");

async function populateOffersTable() {
  const connection = await oracledb.getConnection({
    user: "JOBATHON",
    password: "12345",
    connectString: "localhost/orclpdb",
  });

  try {
    const selectJobsQuery = 'SELECT * FROM "Jobs"'; // Update with your actual table name
    const jobsResult = await connection.execute(selectJobsQuery);

    const insertOffersQuery = `
      INSERT INTO "Offers" ("JobID", "Company_ID")
      VALUES (:jobId, :companyId)
    `;

    const totalCompanies = 22;

    for (const job of jobsResult.rows) {
      const randomCompanyId = Math.floor(Math.random() * totalCompanies) + 1;

      const bindParams = {
        jobId: job[0],
        companyId: randomCompanyId,
      };

      await connection.execute(insertOffersQuery, bindParams, { autoCommit: true });
      console.log(`Inserted offer for JobID ${job.JOBID} with CompanyID ${randomCompanyId}`);
    }
  } catch (error) {
    console.error("Error inserting offers:", error);
  } finally {
    await connection.close();
  }
}

populateOffersTable();
