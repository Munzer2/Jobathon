document.addEventListener('DOMContentLoaded', async () => {
    console.log('inside cv body');

    let UserID='';  
    let Bio='';
    let awards='';
    let edu='';
    let skill='';
    let lang='';
    let otherJob='';
    let internship='';



    

    const response = await fetch(`/getCV`);
    const cv = await response.json();
 

    
    


      
       

       try{

        const nextButton1 = document.getElementById('next');
        nextButton1.addEventListener('click', async (event) => {
            event.preventDefault();

    
           Bio = document.getElementById('bio').value;
           if(Bio==='' && cv.Bio==null){

            alert('Please Enter your Bio to Proceed');
           }
           else{

            if(Bio===''){

                Bio=cv.Bio;
            }

            const response = await fetch(`/updateCV/next?bio=${Bio}`);
            const data = await response.json();
            
            if(data.success==true){
                window.location.href = `/updateCV`; 
            }
            else{
                alert('failed to go next step Update your Profile First');
            }


           }
            
           

    
               
           });

         
       }catch(error){
        console.log(error)
       }

      
       try{

        const nextButton2 = document.getElementById('next2');
        nextButton2.addEventListener('click', async (event) => {
            event.preventDefault();
           
    
    
            awards= document.getElementById('awards').value;
            lang = document.getElementById('lang').value; 
            edu= document.getElementById('edu').value; 
            skill = document.getElementById('skill').value;
            // if(awards===''){use a if else if data.awards==null or not null
                
            // }

            if(awards==='' && cv.awards==null){
                awards='no awards';
            }
            else{

                if(awards===''){
                    awards=cv.awards;
                }
            }
            if(lang==='' || edu==='' || skill===''){

                if(cv.lang!=null && cv.edu!=null && cv.skill !=null){
                    lang=cv.lang;
                    edu=cv.edu;
                    skill=cv.skill;


                    const response = await fetch(`/updateCV/next2?awards=${awards}&lang=${lang}&edu=${edu}&skill=${skill}`);
                    const data = await response.json();
                    
                    if(data.success==true){
                        window.location.href = `/updateCV`; 
                    }
                    else{
                        alert('failed to go next step Update your Profile First');
                    }

                }else{
                    alert('Please fill up Language , Educational BackGround and Your Skill');
                }
               
            }
           
            
      
    
           });

         
       }catch(error){
        console.log(error)
       }

       try{

        const nextButton2 = document.getElementById('next3');
        nextButton2.addEventListener('click', async (event) => {
            event.preventDefault();
           
    
    
            otherJob= document.getElementById('ojob').value;
            internship= document.getElementById('in').value; 

            // if(awards===''){use a if else if data.awards==null or not null
                
            // }

            if(otherJob==='' && cv.otherJob==null){
                otherJob=null;
            }else{
                  if(otherJob!=null){

                    otherJob=cv.otherJob;
                  }


            }
            if(internship==='' && cv.internship==null){
                internship=null;
            }else{
                  if(internship!=null){

                    internship=cv.internship;
                  }


            }

           
           

                const response = await fetch(`/updateCV/next3?ojob=${otherJob}&intern=${internship}`);
                const data = await response.json();
                
                if(data.success==true){
                    window.location.href = `/updateCV`; 
                }
                else{
                    alert('failed to go next step Update your Profile First');
                }


       
            
      
    
           });

         
       }catch(error){
        console.log(error)
       }


       
       try{

        const updateButton = document.getElementById('update');
        updateButton.addEventListener('click', async (event) => {
            event.preventDefault();

            const response = await fetch(`/insertCV/Info`);
            const data = await response.json();
            if(data.success===true){
                alert('CV sucessfully Updated');
                window.location.href = `/user/${cv.UserID}`; 

            }
            else{
                alert('error');
            }
    
            
           });

         
       }catch(error){
        console.log(error)
       }
      






});

