const oracledb = require("oracledb");
const axios = require("axios");
const crypto = require("crypto");
const path = require("path");
const bodyParser = require('body-parser');
const socketIo = require('socket.io');
const http = require('http');


const express = require('express');
const { connect } = require("http2");
oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;

const app = express();


app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));


app.use(express.static('public'));
// app.listen(3000);
const server = http.createServer(app);
server.listen(3000);
const io = socketIo(server);

app.use(bodyParser.json());


const users = {};
const messages = [];
class Person {
    constructor(UserID,firstName, lastName,City,Postal,State,Country, age,Gender,Phone,ComID,  CEO_of_Company, Type,Photo,
        ComName,ComMainBranch,ComIndustry,ComOrigin,JobTitle,JobSalary,Password
        
        ) {

      this.UserID= UserID;  
      this.firstName = firstName;
      this.lastName = lastName;
      this.City = City;
      this.Postal =Postal;
      this.State =State;
      this.Country =Country;
      this.age = age;
      this.Gender =Gender;
      this.Phone = Phone;
      this.ComID =ComID;
      this.CEO_Of_Company=CEO_of_Company;
      this.Type = Type;
      this.Photo = Photo;
      this.ComName =ComName;
      this.ComMainBranch=ComMainBranch;
      this.ComIndustry=ComIndustry;
      this.ComOrigin=ComOrigin;
      this.JobTitle=JobTitle;
      this.JobSalary=JobSalary;
      this.Password=Password;
      this.flag=1


    }
  }
class CV {    
    
    constructor(UserID,Bio,awards,lang,edu,skill,pastJobArray,otherJob,internship,firstUpdate
    
    ) {

  this.UserID=UserID;      
  this.Bio=Bio;
  this.awards=awards;
  this.lang=lang;
  this.edu=edu;
  this.skill=skill;
  this.pastJobArray=pastJobArray;
  this.otherJob=otherJob;
  this.internship=internship;
  this.firstUpdate=firstUpdate;
  this.flag=1


}

addData(data) {
    this.pastJobArray.push(data);
}


}  
  
  let adnanInfo =null ;
  let cvInfo=null;  


io.on('connection', (socket) => {
    console.log('User connected:', socket.id);
    socket.on('disconnect', () => {
        console.log('User disconnected:', socket.id);
    });
    socket.on('Private message', async (message, targetUserId, senderID) => {
        // Send the message only to the target user
        messages.push(message);
        const targetSocket = users[targetUserId];
        if (targetSocket) {
            targetSocket.emit('Private message', message, targetUserId, senderID);
        }
        socket.emit('Send to thyself', message);
        try {
            const connection = await oracledb.getConnection({
                user: 'JOBATHON',
                password: '12345',
                connectString: 'localhost/orclpdb',
            });

            const query = `INSERT INTO "Messages" VALUES (:sender_id, :recipient_id, :content, SYSTIMESTAMP)`;
            const binds = { sender_id: senderID, recipient_id: targetUserId, content: message };
            const options = { autoCommit: true };

            const result = await connection.execute(query, binds, options);
            await connection.close();
            console.log('Message stored in the database successfully');
        } catch (error) {
            console.error('Error storing message in the database:', error);
        }
    });
    // Store the user's socket for private messaging
    socket.on('set user', (userId) => {
        users[userId] = socket;
    });
});


////Basic: 
app.get('/api/messages1', async (req, res) => {
    const currentUserId = req.query.userID;
    const targetUserId = req.query.targetUserID;
    const query = `
        SELECT "Sender_ID", "Recipient_ID", "Message"
        FROM "Messages"
        WHERE "Sender_ID" = '${currentUserId}' AND "Recipient_ID" = '${targetUserId}' 
        OR "Sender_ID" = '${targetUserId}' AND "Recipient_ID" = '${currentUserId}'
        ORDER BY "Timestamp"
    `;

    try {
        const result = await run(query);

        res.json(result.rows);
    } catch (error) {
        console.error('Error fetching past messages:', error);
        res.status(500).json({ error: 'Error fetching past messages' });
    }
});

///Basic:
app.get('/api/messages', async (req, res) => {
    res.json(messages);
});



async function run(query) {
    const connection = await oracledb.getConnection({
        user: 'JOBATHON',
        password: '12345',
        connectString: 'localhost/orclpdb',
    });

    try {
        const data = await connection.execute(query);
        return data;
    }
    finally {
        await connection.close(); //Always close connections.
    }
}


async function run2(query, params) {
    let connection;
    try {
        connection = await oracledb.getConnection({
            user: 'JOBATHON',
            password: '12345',
            connectString: 'localhost/orclpdb',
        });

        const result = await connection.execute(query, params);

        return result;
    } catch (error) {
        console.error('Error executing query:', error);
        throw error;
    } finally {
        if (connection) {
            try {
                await connection.close();
            } catch (error) {
                console.error('Error closing connection:', error);
            }
        }
    }
}

///Basic:
app.get('/verifyLogin', async (req, res) => {
    let user = req.query.username;
    let pass = req.query.password;
    const hashedPassword = crypto.createHash('sha256').update(pass).digest('hex');
    const query = `SELECT * FROM "User" WHERE "UserID" = '${user}' AND "Password(hashed)" = '${hashedPassword}'`;
    try {
        const result = await run(query);
        if (result.rows.length == 1) {
            const response = await fetch(`http://localhost:3000/makeAdnan?username=${user}&password=${pass}`);
            const data = await response.json();
            const response1 = await fetch(`http://localhost:3000/makecvInfo`);
            const data1 = await response1.json();

            res.status(200).json({ success: true });
        }
        else res.status(200).json({ success: false });
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ success: false });
    }
});

///Basic:
app.get('/getfirstname/:userID', async (req, res) => {
    const ID = req.params.userID;
    const query = `SELECT "firstName" FROM "User" WHERE "UserID" = '${ID}'`;
    try {
        const result = await run(query);
        if (result.rows.length == 1) {
            res.status(200).json({ success: true, firstName: result.rows[0].firstName });
        }
        else res.status(200).json({ success: false });
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ success: false });
    }

});


///Basic:
app.get('/user/:username', async (req, res) => {
    const username = req.params.username;
    const query = `SELECT * FROM "User" WHERE "UserID" = '${username}'`;
    try {
        const user_info = await run(query);
        res.render('userProfile', { user: user_info.rows[0] });
    }
    catch (error) {
        console.log("Error!");
    }
});

////Basic:
app.get('/fetchHobbies/:userID', async (req, res) => {
    const userID = req.params.userID;
    const query = `SELECT "Hobby" FROM "Hobbies" WHERE "User_ID" = '${userID}'`;

    try {
        const hobbies_result = await run(query);
        const hobbies = hobbies_result.rows.map(row => row.Hobby);
        res.status(200).json(hobbies);
    } catch (error) {
        console.error('Error fetching hobbies:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

///Basic: 
app.get('/fetchFavJobs/:userID', async (req, res) => {
    const userID = req.params.userID;

    const query = `
        SELECT * FROM "Jobs_of_Interest" WHERE "ID_of_User" = :userID
    `;

    try {
        const result = await run2(query, { userID });

        res.status(200).json(result.rows);
    } catch (error) {
        console.error('Error fetching favorite jobs:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

///Basic
app.get('/fetchJobDetails3/:JobID', async (req, res) => {
    const jobID = req.params.JobID;
    const query = `
        SELECT * FROM "Jobs" WHERE "JobID" = :jobID
    `;
    try {
        const result = await run2(query, { jobID });
        res.status(200).json(result.rows);
    }
    catch (error) {
        console.error('Error fetching Job details.', error);
        res.status(500).json({ error: 'Internal server error' });
    }
})

///Delete Jobs query. 
app.get('/deleteJobOfInterest', async (req, res) => {
    const userID = req.query.userID;
    const jobID = req.query.jobID;
    console.log(userID);
    const deleteQuery = `
        DELETE FROM "Jobs_of_Interest"
        WHERE "ID_of_User" = '${userID}' AND "Wanted_JobID" = '${jobID}'
    `;
    const connection = await oracledb.getConnection({
        user: 'JOBATHON',
        password: '12345',
        connectString: 'localhost/orclpdb',
    });
    try {
        const result = await connection.execute(deleteQuery);

        await connection.commit();
        res.status(200).send('Job deleted from interests successfully.');
    } catch (error) {
        console.error('Error deleting job from interests:', error);

        if (connection) {
            await connection.rollback();
        }
        res.status(500).send('Failed to delete job from interests.');
    }
    await connection.close();
});


///Insert query: 
app.post('/addHobby', async (req, res) => {
    const userID = req.body.userID;
    const hobby = req.body.hobby;

    const insertQuery = `
        INSERT INTO "Hobbies" ("User_ID", "Hobby")
        VALUES (:userID, :hobby)
    `;

    try {
        const connection = await oracledb.getConnection({
            user: 'JOBATHON',
            password: '12345',
            connectString: 'localhost/orclpdb',
        });

        const result = await connection.execute(insertQuery, {
            userID,
            hobby,
        });

        await connection.close();

        console.log('Hobby added:', result);

        res.status(200).json({ success: true });
    } catch (error) {
        console.error('Error adding hobby:', error);
        res.status(500).json({ success: false });
    }
});

///Basic:
app.get('/fetchCompany/:companyId', async (req, res) => {
    const companyId = req.params.companyId;
    const query = `SELECT * FROM "Company" WHERE "CompanyID" = '${companyId}'`;

    try {
        const companyDetails = await run(query);
        res.json(companyDetails.rows[0]);
    } catch (error) {
        console.error('Error fetching company details:', error);
        res.status(500).json({ error: 'An error occurred while fetching company details' });
    }
});

///Basic:
app.get('/fetchReviews/:ID', async (req, res) => {
    const ID = req.params.ID;
    const query = `SELECT * FROM "Review" WHERE "ReviewerID" = '${ID}'`;

    try {
        const revDetails = await run(query);
        res.json(revDetails.rows);
    } catch (error) {
        console.error('Error fetching reviews details:', error);
        res.status(500).json({ error: 'An error occurred while fetching company details' });
    }
});


////Triple Join.
app.get('/fetchJobDetails/:userID', async (req, res) => {
    const userID = req.params.userID;
    const query = `
    SELECT J."Title", J."Salary"
    FROM "User" U JOIN   "JobPositions" JP ON U."UserID" = JP."WorkerID" 
    JOIN "Jobs" J ON JP."CurrentJobID" = J."JobID" WHERE U."UserID" = '${userID}'
    `;

    try {
        const jobDetails = await run(query);
        res.status(200).json(jobDetails.rows);
    } catch (error) {
        console.error('Error fetching job details:', error);
        res.status(500).json({ error: 'An error occurred while fetching job details' });
    }
});

///Join.
app.get('/fetchJobDetails2/:userID', async (req, res) => {
    const userID = req.params.userID;
    const query = `
      SELECT *
      FROM "JobPositions" JP
      INNER JOIN "Jobs" J ON JP."CurrentJobID" = J."JobID"
      WHERE JP."WorkerID" = '${userID}'
    `;

    try {
        const jobDetails = await run(query);
        res.status(200).json(jobDetails.rows[0]);
    } catch (error) {
        console.error('Error fetching job details:', error);
        res.status(500).json({ error: 'An error occurred while fetching job details' });
    }
});

///Subquery: 
app.get('/fetchHigherPayingJobs/:userID', async (req, res) => {
    const userID = req.params.userID;
    try {
        const higherPayingJobsQuery = `
        SELECT * FROM "Jobs" WHERE "Salary" > ( SELECT "Salary" FROM "Jobs" WHERE "JobID" = (SELECT "CurrentJobID" FROM "JobPositions" WHERE "WorkerID" = '${userID}'))
      `;

        const higherPayingJobsResult = await run(higherPayingJobsQuery);
        const higherPayingJobs = higherPayingJobsResult.rows;

        res.json(higherPayingJobs);
    } catch (error) {
        console.error('Error fetching higher paying jobs:', error);
        res.status(500).json({ error: 'An error occurred while fetching higher paying jobs' });
    }
});

///Advanced:
app.get('/fetchLowerPayingJobs/:userID', async (req, res) => {
    const userID = req.params.userID;
    try {
        const lowerPayingJobsQuery = `
        SELECT * FROM "Jobs" WHERE "Salary" < ( SELECT "Salary" FROM "Jobs" WHERE "JobID" = (SELECT "CurrentJobID" FROM "JobPositions" WHERE "WorkerID" = '${userID}'))
      `;

        const lowerPayingJobsResult = await run(lowerPayingJobsQuery);
        const lowerPayingJobs = lowerPayingJobsResult.rows;

        res.json(lowerPayingJobs);
    } catch (error) {
        console.error('Error fetching higher paying jobs:', error);
        res.status(500).json({ error: 'An error occurred while fetching higher paying jobs' });
    }
});

///Advanced:
app.get('/fecthLowerRatedJobs', async(req, res) => {
    try {
        const lowerJobsQuery = `
        SELECT J."JobID", J."Title", J."Salary", J."Category"  FROM "Jobs" J JOIN (SELECT "ReviewedCompanyID", Avg("Reviews") FROM "Review" group by "ReviewedCompanyID"
         HAVING AVG("Reviews") < 3 )R
        ON J."JobID" = R."ReviewedCompanyID" GROUP BY J."JobID", J."Title", J."Salary", J."Category"
      `;
        const lowerratedres = await run(lowerJobsQuery);
        const lowerratedJobs = lowerratedres.rows;  
        res.json(lowerratedJobs);
    } catch (error) {
        console.error('Error fetching higher paying jobs:', error);
        res.status(500).json({ error: 'An error occurred while fetching higher paying jobs' });
    }
}); 

///Advanced: 
app.get('/fecthMytypeOfJobs/:userID', async (req, res) => {
    const userID = req.params.userID;
    try {
        const query= `SELECT * FROM "Jobs" WHERE "Category" = (SELECT "Category" FROM "Jobs" WHERE "JobID" =(SELECT "CurrentJobID" FROM "JobPositions" WHERE "WorkerID" = '${userID}'))`;
        const MytypeofJobs = await run(query);
        res.json(MytypeofJobs.rows);
    }
    catch (error) {
        console.error('Error fetching same type of jobs:', error);
        res.status(500).json({ error: 'An error occurred while fetching same type of jobs.' });
    }
});

///Join: 
app.get('/fetchCompaniesbyJobID/:JobID', async (req, res) => {
    const jobID = req.params.JobID;
    const query1 = `SELECT C."Name" FROM "Company" C JOIN "Jobs" J ON C."Industry" = J."Category" AND J."JobID" = '${jobID}'`;
    try {
        const response = await run(query1);
        res.json(response.rows);
    }
    catch (error) {
        console.error('Error fetching details:', error);
        res.status(500).json({ error: 'An error occurred while fetching companies.' });
    }
});

///Advanced: 
app.get('/fetchSimilarUsers/:UserID', async (req, res) => {
    const UserID = req.params.UserID;
    const industryQuery = `SELECT "Industry" FROM "Company" WHERE "CompanyID" = (SELECT "ComID" FROM "User" WHERE "UserID" = '${UserID}')`;
    const industryResult = await run(industryQuery);
    const industry = industryResult.rows[0].Industry;

    const Query1 = `
                SELECT * FROM "User"
                WHERE "ComID" IN (
                    SELECT "CompanyID" FROM "Company" WHERE "Industry" = '${industry}'
                ) AND "UserID" != '${UserID}'
            `;
    try {
        const similarUsers = await run(Query1);
        res.json(similarUsers.rows);
    }
    catch (error) {
        console.error('Error fetching similar users:', error);
        res.status(500).json({ error: 'An error occurred while fetching similar users' });
    }
});

///Basic: 
app.get('/fetchAllJobs', async (req, res) => {
    const query = `SELECT * FROM "Jobs"`;
    try {
        const all_jobs = await run(query);
        res.json(all_jobs.rows);
    }
    catch (error) {
        console.error('Error fetching the jobs.');
    }
});

///Insertion:
app.post('/addToInterests', async (req, res) => {

    const connection = await oracledb.getConnection({
        user: 'JOBATHON',
        password: '12345',
        connectString: 'localhost/orclpdb',
    });

    const { ID_of_User, Wanted_JobID } = req.body;
    if (!ID_of_User || !Wanted_JobID) {
        return res.status(400).send('User ID and Job ID are required.');
    }
    const insertQuery = `INSERT INTO "Jobs_of_Interest" VALUES (:ID_of_User, :Wanted_JobID)`;
    try {
        const result = await connection.execute(insertQuery, {
            ID_of_User: ID_of_User,
            Wanted_JobID: Wanted_JobID
        });
        await connection.commit();
        await connection.close();
        res.status(200).send('Job added to interests successfully.');
    } catch (error) {
        console.error('Error:', error);
        res.status(500).send('Failed to add job to interests.');
    }
});

////Basic;
app.get('/fetchAllEmployers', async (req, res) => {
    const query = `SELECT * FROM "User" WHERE "Type" = 'Employer'`;
    try {
        const result = await run(query);
        res.json(result.rows);
    }
    catch (error) {
        console.error(error);
    }
});

app.get('/advanced-search/:userID', async (req, res) => {
    const userID = req.params.userID;
    res.render('Advanced_search', { user: userID });
});


////Basic: 
app.get('/fetchUsertype/:userID', async (req, res) => {
    const userID = req.params.userID;
    const query = `SELECT "Type" FROM "User" WHERE "UserID" = '${userID}'`;
    try {
        const response = await run(query);
        if (response.rows.length == 1) {
            const userType = response.rows[0].Type;
            res.status(200).json({ userType });
        }
        else {
            res.status(404).json({ error: 'Type not found' });
        }
    }
    catch (error) {
        console.error(error);
    }
});


app.get('/ApplyForJobs', async (req, res) => {
    const jobID = req.query.jobID;
    res.render('ApplyForJobs', { jobID: jobID });
});

///Join:
app.get('/fetchEmployersForJob/:jobID', async (req, res) => {
    const jobID = parseInt(req.params.jobID, 10); 
    try {
        const query = `
        SELECT U."firstName", U."lastName", U."Phone", U."Country",U."ComID"
        FROM "User" U
        JOIN "Offers" O ON U."ComID" = O."Company_ID"
        WHERE O."JobID" = :jobID AND U."Type" = 'Employer'
      `;
        const result = await run2(query, { jobID });

        res.status(200).json(result.rows);
    } catch (error) {
        console.error('Error fetching employers for job:', error);
        res.status(500).json({ error: 'Failed to fetch employers for job.' });
    }
});

///Basic:
app.get('/fetchCompaniesByIndustry/:industry', async (req, res) => {
    const industry = req.params.industry;
    const query = `
        SELECT * FROM "Company" WHERE "Industry" = :industry
    `;
    try {
        const result = await run2(query, { industry });
        res.status(200).json(result.rows);
    } catch (error) {
        console.error('Error fetching companies by industry:', error);
        res.status(500).json({ error: 'Failed to fetch companies by industry' });
    }
});

////Procedure
app.get('/getCityAndPostal/:userID', async (req, res) => {
    const userID = req.params.userID;
    const connection = await oracledb.getConnection({
        user: 'JOBATHON',
        password: '12345',
        connectString: 'localhost/orclpdb',
    });
  
    try {
      const plsql = `
        BEGIN
          GetCityAndPostal(:userID, :city, :postal);
        END;
      `;
      const bindParams = {
        userID: userID,
        city: { type: oracledb.STRING, dir: oracledb.BIND_OUT },
        postal: { type: oracledb.STRING, dir: oracledb.BIND_OUT },
      };
      const result = await connection.execute(plsql, bindParams);
  
      const city = result.outBinds.city;
      const postal = result.outBinds.postal;
      res.json({ city, postal });
    } catch (error) {
      console.error('Error calling procedure:', error);
      res.status(500).json({ error: 'Failed to get city and postal' });
    } finally {
      if (connection) {
        await connection.close();
      }
    }
  });


////---------------------------------------------------------------------------------------------------------------------------------
///Adnans part:
app.get('/signUpCheck', async(req,res)=>{
    let user =req.query.username;
    let pass =req.query.password;
    const hashedPassword = crypto.createHash('sha256').update(pass).digest('hex');
    const query = `SELECT * FROM "User" WHERE "UserID" = '${user}'`; 
    try{
        const result = await run(query); 
        ///console.log(result.rows);
        if( result.rows.length == 0 )
        {
            res.status(200).json({ success: true });
        }
        else res.status(200).json({ success: false });
    }
    catch(error)
    {
        console.error(error);
        res.status(500).json({ success: false });
    }
});  

app.post('/signUpInsert', async (req, res) => {

    console.log('adnan');

    const connection = await oracledb.getConnection({
        user: 'JOBATHON',
        password : '12345',
        connectString: 'localhost/orclpdb',
    });

    const { ID_of_User, firstname,lastname, password } = req.body;
    if (!ID_of_User || !password) {
        return res.status(400).send('User ID and password are required.');
    }

    let attention='attention required';
    let zero=0;
    let userID=ID_of_User;
    let firstName=firstname;
    let lastName=lastname;
    let City=attention;
    let Postal=attention;
    let state=attention;
    let Country=attention;
    let Age=zero;
    let gender=attention;
    let phone=attention;
    let cpID=0;
    let CEO_Of_Company='null';
    let type=attention;
    let pic_url_med=attention; 
    let hashedPassword=crypto.createHash('sha256').update(password).digest('hex');

    console.log(userID);
    console.log(firstName);
    console.log(lastName);
    console.log(hashedPassword);
    


    const insertQuery=`
    
       INSERT INTO "User" 
       VALUES(:userID, :firstName, :lastName, :City, :Postal, :state, :Country, :Age, :gender, :phone, : cpID, :CEO_Of_Company, :type, :pic_url_med, :hashedPassword)
    
    
    `;

      
    try {
        const result = await connection.execute(insertQuery,{

            userID,
            firstName,
            lastName,
            City,
            Postal,
            state,
            Country,
            Age,
            gender,
            phone,
            cpID,
            CEO_Of_Company,
            type,
            pic_url_med, 
            hashedPassword



        });
        await connection.commit(); 
        await connection.close(); 
        res.status(200).send('User added to  successfully.');
    } catch (error) {
        console.error('Error:', error);
        res.status(500).send('Failed to add user');
    }
});


app.get('/makeAdnan', async(req,res)=>{

    let user =req.query.username;
    let pass =req.query.password;
    const hashedPassword = crypto.createHash('sha256').update(pass).digest('hex');
    
    const query = `
    SELECT * 
    FROM "User" U
    LEFT OUTER JOIN "Company" C ON U."ComID"=C."CompanyID"
    LEFT OUTER JOIN "JobPositions" P ON U."UserID"= P."WorkerID"
    LEFT OUTER JOIN "Jobs" J ON J."JobID"=P."CurrentJobID"
    WHERE "UserID" = '${user}'
    `; 
    
    try{
        const result = await run(query);
        console.log(result.rows[0]['Password(hashed)']); 

      
        if( result.rows.length == 1 )
        {

         adnanInfo = new Person(result.rows[0].UserID,result.rows[0].firstName,result.rows[0].lastName,result.rows[0].City,
            result.rows[0].Postal,result.rows[0].State,result.rows[0].Country,result.rows[0].Age,result.rows[0].Gender,result.rows[0].Phone,result.rows[0].ComID,
            result.rows[0].CEO_Of_Company,result.rows[0].Type,result.rows[0].Photo,result.rows[0].Name,result.rows[0].Main_Branch,result.rows[0].Industry,
            result.rows[0].Origin,result.rows[0].Title,result.rows[0].Salary,result.rows[0]['Password(hashed)']);

    
            res.status(200).json({ success: true });
        }
        else res.status(200).json({ success: false });
    }
    catch(error)
    {
        console.error(error);
        res.status(500).json({ success: false });
    }
});

app.get('/getAdnan', async(req,res) =>{

    if(adnanInfo != null){

        res.status(200).json( adnanInfo);
    }
    else{

    }

}); 

app.get('/updateInfo', async(req,res)=>{
  
    console.log(adnanInfo);

try
{
    
    res.render('updateInfo',{adnanInfo}); // Pass user_info, hobbies to the template
}  
catch(error) 
{
    console.log("Error!");
}

}); 
app.get('/getComInfo', async(req,res)=>{

    let comName =req.query.ComName.toUpperCase();

    
    const query = `
    SELECT * FROM "Company" 
    WHERE UPPER("Name") = '${comName}'
    `; 
    
    try{
        const result = await run(query); 

      
        if( result.rows.length == 1 )
        {

            res.status(200).json({user : result.rows[0] , success: true});
        }
        else res.status(200).json({ success: false });
    }
    catch(error)
    {
        console.error(error);
        res.status(500).json({ success: false });
    }
}); 

app.get('/changeFlag/:firstname/:lastname/:age/:gender/:type/:phone/:ComName', async(req,res) =>{

    const firstname = req.params.firstname;
    const lastname = req.params.lastname;
    const age = req.params.age;
    const gender = req.params.gender;
    const type = req.params.type;
    const phone = req.params.phone;
    const comname = req.params.ComName;
   
    console.log(adnanInfo);
    if(adnanInfo.flag==1){
        console.log(phone);
        adnanInfo.firstName=firstname;
        adnanInfo.lastName=lastname;
        adnanInfo.age=age;
        adnanInfo.Gender=gender;
        adnanInfo.Type=type;
        adnanInfo.Phone=phone;
        adnanInfo.flag=2; 
        adnanInfo.ComName=comname;    

    try
    {
    
    res.render('updateInfo',{adnanInfo}); // Pass user_info, hobbies to the template
    
    }  
    catch(error)   
    {
    console.log("Error!");
    }

    }
    else if(adnanInfo.flag==2){
    console.log(firstname);    
    const state=firstname;
    const postal=lastname;
    const city=age;
    const country=gender;
     
    adnanInfo.State=state;
    adnanInfo.Postal=postal;
    adnanInfo.City=city;
    adnanInfo.Country=country;
    adnanInfo.flag=3;
    console.log(adnanInfo);

    
    try
    {

        const responseCom = await fetch(`http://localhost:3000/getComInfo?ComName=${adnanInfo.ComName}`);
        const dataCom = await responseCom.json();
        console.log(dataCom);
        if(dataCom.success){
            adnanInfo.ComOrigin=dataCom.user.Origin;
            adnanInfo.ComIndustry=dataCom.user.Industry;
            adnanInfo.ComMainBranch=dataCom.user.Main_Branch;
            adnanInfo.ComID=dataCom.user.CompanyID;
            adnanInfo.CEO_Of_Company=dataCom.user.CEO;
            
        }
    
    res.render('updateInfo',{adnanInfo}); // Pass user_info, hobbies to the template
    
    }  
    catch(error)   
    {
    console.log("Error!");
    }



    }


});
app.get('/updateUpdate/Info', async (req, res) => {

    console.log('updateInsert');

    const connection = await oracledb.getConnection({
        user: 'JOBATHON',
        password : '12345',
        connectString: 'localhost/orclpdb',
    });

    

    
    let userID=adnanInfo.UserID;
    let firstName=adnanInfo.firstName;
    let lastName=adnanInfo.lastName;
    let City=adnanInfo.City;
    let Postal=adnanInfo.Postal;
    let state=adnanInfo.State;
    let Country=adnanInfo.Country;
    let Age=adnanInfo.age;
    let gender=adnanInfo.Gender;
    let phone=adnanInfo.Phone;
    let cpID=adnanInfo.ComID;
    let CEO_Of_Company=adnanInfo.CEO_Of_Company;
    let type=adnanInfo.Type;
    let pic_url_med=adnanInfo.Photo; 
    let hashedPassword=adnanInfo.Password;

    console.log(userID);
    console.log(firstName);
    console.log(lastName);
    console.log(hashedPassword);
    


    const insertQuery=`
    UPDATE "User" 
    SET "firstName"=:firstName , "lastName"=:lastName, "City"=:City, "Postal"=:Postal, "State"=:state, "Country"=:Country,"Age"=:Age,"Gender"=:gender,"Phone"=:phone,
    "ComID"=:cpID, "CEO_of_Company"=:CEO_Of_Company, "Type"=:type, "Photo"=:pic_url_med,"Password(hashed)"=:hashedPassword
    WHERE "UserID"=:userID
    
    `;

      
    try {
        const result = await connection.execute(insertQuery,{

            userID,
            firstName,
            lastName,
            City,
            Postal,
            state,
            Country,
            Age,
            gender,
            phone,
            cpID,
            CEO_Of_Company,
            type,
            pic_url_med, 
            hashedPassword



        });
     
        await connection.commit(); 
        await connection.close(); 
        adnanInfo.flag=1;
        res.status(200).send({success: true});
    } catch (error) {
        console.error('Error:', error);
        res.status(500).send({success: false});
    }
});
app.get('/updateInsert/Company/:title', async (req, res) => {



    const connection = await oracledb.getConnection({
        user: 'JOBATHON',
        password : '12345',
        connectString: 'localhost/orclpdb',
    });

    

    let title = req.params.title;
    let userID=adnanInfo.UserID;
    let industry=adnanInfo.ComIndustry;

    console.log('414');
    console.log(userID);
    console.log(title);

    let errorCheck=0;

    if(adnanInfo.JobTitle==null){
        console.log('414');
        console.log('iside null');


        const insertQuery=`INSERT INTO "JobPositions" VALUES(:userID,GET_JOB_ID(:title,:industry)) `;

      
        try {
            const result = await connection.execute(insertQuery,{
    
                userID,
                title,
                industry
    
    
    
            });
            console.log('update company 1');
            console.log(result);
            await connection.commit(); 
            await connection.close();
            const responseCom = await fetch(`http://localhost:3000/getTitleInfo`);
            const dataCom = await responseCom.json();
            console.log('414');
            console.log('gwt titlkw indo');
            console.log(dataCom);
            adnanInfo.CurrentJobID=dataCom.user.JobID;
            adnanInfo.JobTitle=dataCom.user.Title;
            adnanInfo.JobSalary=dataCom.user.Salary;
            adnanInfo.flag=1; 
            res.status(200).send({success: true});
        } catch (error) {
            errorCheck=-1;
            console.error('Error:', error);
            res.status(500).send({success: false});
        }

    }
    else{
        console.log('414');
        console.log('iside not null');

        const insertQuery=`UPDATE "JobPositions" SET "CurrentJobID"=GET_JOB_ID(:title,:industry) WHERE "WorkerID"=:userID`;

      
        try {
            const result = await connection.execute(insertQuery,{
    
                userID,
                title,
                industry
    
    
    
            });
            console.log('update company 2');
            console.log(result);
            await connection.commit(); 
            await connection.close(); 
            const responseCom = await fetch(`http://localhost:3000/getTitleInfo`);
            const dataCom = await responseCom.json();
            console.log('414');
            console.log('gwt titlkw indo');
            console.log(dataCom);
            adnanInfo.CurrentJobID=dataCom.user.JobID;
            adnanInfo.JobTitle=dataCom.user.Title;
            adnanInfo.JobSalary=dataCom.user.Salary;
            adnanInfo.flag=1;
            res.status(200).send({success: true});
        } catch (error) {
            errorCheck=-1;
            console.error('Error:', error);
            res.status(500).send({success: false});
        }


    }


    




    
});
app.get('/getTitleInfo', async(req,res)=>{


    const query = `
    SELECT * 
    FROM "JobPositions" JP
    JOIN "Jobs" J ON JP."CurrentJobID"=J."JobID"
    WHERE UPPER("WorkerID")=UPPER('${adnanInfo.UserID}')
    `; 
    
    try{
        const result = await run(query); 

      
        if( result.rows.length == 1 )
        {

            res.status(200).json({user : result.rows[0] , success: true});
        }
        else res.status(200).json({ success: false });
    }
    catch(error)
    {
        console.error(error);
        res.status(500).json({ success: false });
    }
}); 
app.get('/makecvInfo', async(req,res)=>{


    
    const query = `
    SELECT * from "CV"
    WHERE "UserID" = '${adnanInfo.UserID}'
    `; 
    
    try{
        const result = await run(query);


      
        if( result.rows.length == 1 )
        {

            const originalStrings = result.rows[0].CV.split('$');
            
            cvInfo =new CV(adnanInfo.UserID,originalStrings[0],originalStrings[1],originalStrings[2],originalStrings[3],originalStrings[4],[],originalStrings[5],originalStrings[6],false);
          

            const response1 = await fetch(`http://localhost:3000/get/PastJob`);
            const data1 = await response1.json();
            


            console.log(cvInfo);
            res.status(200).json({ success: true });
        }
        else {

            cvInfo =new CV(adnanInfo.UserID,null,null,null,null,null,[],null,null,true);
            console.log(cvInfo);
            res.status(200).json({ success: true });
            
        }
    }
    catch(error)
    {
        console.error(error);
        res.status(500).json({ success: false });
    }
});
app.get('/updateCV', async(req,res)=>{
  

    try
    {
        
        res.render('CV',{adnanInfo :adnanInfo, cvInfo : cvInfo}); // Pass user_info, hobbies to the template
    }  
    catch(error) 
    {
        console.log("Error!");
    }
    
}); 
app.get('/getCV', async(req,res) =>{

        if(cvInfo != null){
    
            res.status(200).json( cvInfo);
        }
        else{
    
        }
    
});
app.get('/updateCV/next', async(req,res) =>{
      
        let bio = req.query.bio;
        cvInfo.Bio=bio;
        cvInfo.flag=2;
        try{
          
    
                res.status(200).json({ success: true});
          
        }
        catch(error)
        {
            console.error(error);
            res.status(500).json({ success: false });
        }
    
    
    
    
});
    
app.get('/updateCV/next2', async(req,res) =>{
      
        let awards = req.query.awards;
        let lang = req.query.lang;
        let edu = req.query.edu;
        let skill = req.query.skill;
        cvInfo.flag=3;
        cvInfo.awards=awards;
        cvInfo.lang=lang;
        cvInfo.edu=edu;
        cvInfo.skill=skill;
        try{
            console.log('hereUpdate'); 
                res.status(200).json({ success: true});
    
        }
        catch(error)
        {
            console.error(error);
            res.status(500).json({ success: false });
        }
    
    
    
    
});
    
app.get('/get/PastJob', async(req,res)=>{
    
    
        const query = `
        SELECT DISTINCT "User_id", "Title","Salary","Name","Main_Branch","Origin","Category"
        FROM "User_Log" U
        JOIN "Company" C ON C."CompanyID"=U."comID"
        JOIN "Jobs" J ON  J."JobID"=U."JobID" 
        WHERE "User_id"='${adnanInfo.UserID}'
        `; 
        
        try{
            const result = await run(query);
    
    
          
            if( result.rows.length >= 1 )
            {
                result.rows.forEach(element => {
                    
                    cvInfo.addData(element);
                });
    
                 for (let i = 0; i < cvInfo.pastJobArray.length; i++) { 
                   
                         console.log(cvInfo.pastJobArray[i]); 
                 }    
    
                res.status(200).json({ success: true });
            }
            else res.status(200).json({ success: false });
        }
        catch(error)
        {
            console.error(error);
            res.status(500).json({ success: false });
        }
}); 
app.get('/updateCV/next3', async(req,res) =>{
      
    let otherJob = req.query.ojob;
    let internship = req.query.intern;
 
    cvInfo.flag=4;
    cvInfo.internship=internship;
    cvInfo.otherJob=otherJob;
    try{

            res.status(200).json({ success: true});

    }
    catch(error)
    {
        console.error(error);
        res.status(500).json({ success: false });
    }




});

app.get('/insertCV/Info', async (req, res) => {

   

    const connection = await oracledb.getConnection({
        user: 'JOBATHON',
        password : '12345',
        connectString: 'localhost/orclpdb',
    });

    

    
    let userID=adnanInfo.UserID;
    let array =[cvInfo.Bio,cvInfo.awards,cvInfo.lang,cvInfo.edu,cvInfo.skill,cvInfo.otherJob,cvInfo.internship];
    let CV=array[0];
    for (let index = 1; index < array.length; index++) {
        if(array[index]==null){
            CV=CV+'$'+'';
        }else{
            CV=CV+'$'+array[index];
        }
         
    }
  
    for (let i = 0; i < cvInfo.pastJobArray.length; i++) {

        
     
        CV=CV+'$'+cvInfo.pastJobArray[i].Title+' Salary: '+cvInfo.pastJobArray[i].Salary+' '+cvInfo.pastJobArray[i].Name+' '+cvInfo.pastJobArray[i].Main_Branch+", "+cvInfo.pastJobArray[i].Origin

        
    }

 

    if(cvInfo.firstUpdate===false){
        const insertQuery=`
        UPDATE "CV" 
        SET "CV"=:CV 
        WHERE "UserID"=:userID
        `;
    
          
        try {
            const result = await connection.execute(insertQuery,{
    
                userID,
                CV
    
    
    
            });
         
            await connection.commit(); 
            await connection.close(); 
            cvInfo.flag=1;
            res.status(200).send({success: true});
        } catch (error) {
            console.error('Error:', error);
            res.status(500).send({success: false});
        }


    }
    else{

        const insertQuery=`
        INSERT INTO "CV" 
        VALUES(:userID,:CV) 
        `;
    
          
        try {
            const result = await connection.execute(insertQuery,{
    
                userID,
                CV
    
    
    
            });
         
            await connection.commit(); 
            await connection.close(); 
            cvInfo.flag=1;
            res.status(200).send({success: true});
        } catch (error) {
            console.error('Error:', error);
            res.status(500).send({success: false});
        }


    }






});