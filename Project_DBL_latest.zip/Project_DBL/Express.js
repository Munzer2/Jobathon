const oracledb = require("oracledb");
const axios = require("axios");
const crypto = require("crypto");
const path = require("path");
const bodyParser = require('body-parser');
const socketIo = require('socket.io');
const http = require('http');


const express = require('express');
oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;

const app = express();


app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));


app.use(express.static('public'));
// app.listen(3000);
const server = http.createServer(app);
server.listen(3000);
const io = socketIo(server);

app.use(bodyParser.json());


const users = {};
const messages = [];



io.on('connection', (socket) => {
    console.log('User connected:', socket.id);
    socket.on('disconnect', () => {
        console.log('User disconnected:', socket.id);
    });
    socket.on('Private message', async (message, targetUserId, senderID) => {
        // Send the message only to the target user
        messages.push(message);
        const targetSocket = users[targetUserId];
        if (targetSocket) {
            targetSocket.emit('Private message', message, targetUserId, senderID);
        }
        socket.emit('Send to thyself', message);
        try {
            const connection = await oracledb.getConnection({
                user: 'JOBATHON',
                password: '12345',
                connectString: 'localhost/orclpdb',
            });

            const query = `INSERT INTO "Messages" VALUES (:sender_id, :recipient_id, :content, SYSTIMESTAMP)`;
            const binds = { sender_id: senderID, recipient_id: targetUserId, content: message };
            const options = { autoCommit: true };

            const result = await connection.execute(query, binds, options);
            await connection.close();
            console.log('Message stored in the database successfully');
        } catch (error) {
            console.error('Error storing message in the database:', error);
        }
    });
    // Store the user's socket for private messaging
    socket.on('set user', (userId) => {
        users[userId] = socket;
    });
});



// Set up an API endpoint for fetching messages
app.get('/api/messages1', async (req, res) => {
    const currentUserId = req.query.userID;
    const targetUserId = req.query.targetUserID;  
    const query = `
        SELECT "Sender_ID", "Recipient_ID", "Message"
        FROM "Messages"
        WHERE "Sender_ID" = '${currentUserId}' AND "Recipient_ID" = '${targetUserId}' 
        OR "Sender_ID" = '${targetUserId}' AND "Recipient_ID" = '${currentUserId}'
        ORDER BY "Timestamp"
    `;

    try {
        const result = await run(query);

        res.json(result.rows);
    } catch (error) {
        console.error('Error fetching past messages:', error);
        res.status(500).json({ error: 'Error fetching past messages' });
    }
});

app.get('/api/messages', async(req, res)=>{
    res.json(messages); 
}); 



async function run(query) {
    const connection = await oracledb.getConnection({
        user: 'JOBATHON',
        password: '12345',
        connectString: 'localhost/orclpdb',
    });

    try {
        const data = await connection.execute(query);
        return data;
    }
    finally {
        await connection.close(); //Always close connections.
    }
}

app.get('/verifyLogin', async (req, res) => {
    let user = req.query.username;
    let pass = req.query.password;
    const hashedPassword = crypto.createHash('sha256').update(pass).digest('hex');
    const query = `SELECT * FROM "User" WHERE "firstName" = '${user}' AND "Password(hashed)" = '${hashedPassword}'`;
    try {
        const result = await run(query);
        ///console.log(result.rows);
        if (result.rows.length == 1) {
            res.status(200).json({ success: true });
        }
        else res.status(200).json({ success: false });
    }
    catch (error) {
        console.error(error);
        res.status(500).json({ success: false });
    }
});

app.get('/getfirstname/:userID', async(req, res)=>{
    const ID = req.params.userID; 
    const query = `SELECT "firstName" FROM "User" WHERE "UserID" = '${ID}'`;
    try{
        const result = await run(query);
        if (result.rows.length == 1) {
            res.status(200).json({ success: true, firstName: result.rows[0].firstName });
        }
        else res.status(200).json({ success: false });
    } 
    catch(error){
        console.error(error);
        res.status(500).json({ success: false });
    }

}); 



app.get('/user/:username', async (req, res) => {
    const username = req.params.username;
    const query = `SELECT * FROM "User" WHERE "firstName" = '${username}'`;
    try {
        const user_info = await run(query);

        res.render('userProfile', { user: user_info.rows[0] });
    }
    catch (error) {
        console.log("Error!");
    }
});

app.get('/fetchHobbies/:userID', async (req, res) => {
    const userID = req.params.userID;
    const query = `SELECT "Hobby" FROM "Hobbies" WHERE "User_ID" = '${userID}'`;

    try {
        const hobbies_result = await run(query);
        const hobbies = hobbies_result.rows.map(row => row.Hobby);
        res.status(200).json(hobbies);
    } catch (error) {
        console.error('Error fetching hobbies:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});


// API endpoint to add a new hobby
app.post('/addHobby', async (req, res) => {
    const userID = req.body.userID;
    const hobby = req.body.hobby;

    const insertQuery = `
        INSERT INTO "Hobbies" ("User_ID", "Hobby")
        VALUES (:userID, :hobby)
    `;

    try {
        const connection = await oracledb.getConnection({
            user: 'JOBATHON',
            password: '12345',
            connectString: 'localhost/orclpdb',
        });

        const result = await connection.execute(insertQuery, {
            userID,
            hobby,
        });

        await connection.close();

        console.log('Hobby added:', result);

        res.status(200).json({ success: true });
    } catch (error) {
        console.error('Error adding hobby:', error);
        res.status(500).json({ success: false });
    }
});


app.get('/fetchCompany/:companyId', async (req, res) => {
    const companyId = req.params.companyId;
    const query = `SELECT * FROM "Company" WHERE "CompanyID" = '${companyId}'`;

    try {
        const companyDetails = await run(query);
        res.json(companyDetails.rows[0]);
    } catch (error) {
        console.error('Error fetching company details:', error);
        res.status(500).json({ error: 'An error occurred while fetching company details' });
    }
});


app.get('/fetchReviews/:ID', async (req, res) => {
    const ID = req.params.ID;
    const query = `SELECT * FROM "Review" WHERE "ReviewerID" = '${ID}'`;

    try {
        const revDetails = await run(query);
        res.json(revDetails.rows);
    } catch (error) {
        console.error('Error fetching reviews details:', error);
        res.status(500).json({ error: 'An error occurred while fetching company details' });
    }
});



app.get('/fetchJobDetails/:userID', async (req, res) => {
    const userID = req.params.userID;
    const query = `
      SELECT J."Title", J."Salary"
      FROM "JobPositions" JP
      INNER JOIN "Jobs" J ON JP."CurrentJobID" = J."JobID"
      WHERE JP."WorkerID" = '${userID}'
    `;

    try {
        const jobDetails = await run(query);
        res.status(200).json(jobDetails.rows);
    } catch (error) {
        console.error('Error fetching job details:', error);
        res.status(500).json({ error: 'An error occurred while fetching job details' });
    }
});

app.get('/fetchJobDetails2/:userID', async (req, res) => {
    const userID = req.params.userID;
    const query = `
      SELECT *
      FROM "JobPositions" JP
      INNER JOIN "Jobs" J ON JP."CurrentJobID" = J."JobID"
      WHERE JP."WorkerID" = '${userID}'
    `;

    try {
        const jobDetails = await run(query);
        res.status(200).json(jobDetails.rows[0]);
    } catch (error) {
        console.error('Error fetching job details:', error);
        res.status(500).json({ error: 'An error occurred while fetching job details' });
    }
});



app.get('/fetchHigherPayingJobs/:userID', async (req, res) => {
    const userID = req.params.userID;
    const userJobQuery = `
      SELECT "CurrentJobID" FROM "JobPositions" WHERE "WorkerID" = '${userID}'
    `;

    try {
        const userJobResult = await run(userJobQuery);
        const userCurrentJobID = userJobResult.rows[0].CurrentJobID;
        const userCurrentJobSalaryQuery = `
        SELECT "Salary" FROM "Jobs" WHERE "JobID" = '${userCurrentJobID}'
      `;

        const userCurrentJobSalaryResult = await run(userCurrentJobSalaryQuery);
        const userCurrentJobSalary = userCurrentJobSalaryResult.rows[0].Salary;
        const higherPayingJobsQuery = `
        SELECT * FROM "Jobs" WHERE "Salary" > ${userCurrentJobSalary}
      `;

        const higherPayingJobsResult = await run(higherPayingJobsQuery);
        const higherPayingJobs = higherPayingJobsResult.rows;

        res.json(higherPayingJobs);
    } catch (error) {
        console.error('Error fetching higher paying jobs:', error);
        res.status(500).json({ error: 'An error occurred while fetching higher paying jobs' });
    }
});




app.get('/fetchSimilarUsers/:UserID', async (req, res) => {
    const UserID = req.params.UserID;
    const industryQuery = `SELECT "Industry" FROM "Company" WHERE "CompanyID" = (SELECT "ComID" FROM "User" WHERE "UserID" = '${UserID}')`;
    const industryResult = await run(industryQuery);
    const industry = industryResult.rows[0].Industry;

    const Query1 = `
                SELECT * FROM "User"
                WHERE "ComID" IN (
                    SELECT "CompanyID" FROM "Company" WHERE "Industry" = '${industry}'
                ) AND "UserID" != '${UserID}'
            `;
    try {
        const similarUsers = await run(Query1);
        res.json(similarUsers.rows);
    }
    catch (error) {
        console.error('Error fetching similar users:', error);
        res.status(500).json({ error: 'An error occurred while fetching similar users' });
    }
});

app.get('/fetchAllJobs', async (req, res) => {
    const query = `SELECT * FROM "Jobs"`;
    try {
        const all_jobs = await run(query);
        res.json(all_jobs.rows);
    }
    catch (error) {
        console.error('Error fetching the jobs.');
    }
});


app.post('/addToInterests', async (req, res) => {

    const connection = await oracledb.getConnection({
        user: 'JOBATHON',
        password: '12345',
        connectString: 'localhost/orclpdb',
    });

    const { ID_of_User, Wanted_JobID } = req.body;
    if (!ID_of_User || !Wanted_JobID) {
        return res.status(400).send('User ID and Job ID are required.');
    }
    const insertQuery = `INSERT INTO "Jobs_of_Interest" VALUES (:ID_of_User, :Wanted_JobID)`;
    try {
        const result = await connection.execute(insertQuery, {
            ID_of_User: ID_of_User,
            Wanted_JobID: Wanted_JobID
        });
        await connection.commit();
        await connection.close();
        res.status(200).send('Job added to interests successfully.');
    } catch (error) {
        console.error('Error:', error);
        res.status(500).send('Failed to add job to interests.');
    }
});


app.get('/fetchAllEmployers', async (req, res) => {
    const query = `SELECT * FROM "User" WHERE "Type" = 'Employer'`;
    try {
        const result = await run(query);
        res.json(result.rows);
    }
    catch (error) {
        console.error(error);
    }
});

app.get('/advanced-search/:userID', (req, res) => {
    const userID = req.params.userID; 
    res.render('Advanced_search', { user: userID }); 
});