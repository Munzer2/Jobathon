const oracledb = require("oracledb");

async function populateOffersTable() {
  const connection = await oracledb.getConnection({
    user: "JOBATHON",
    password: "12345",
    connectString: "localhost/orclpdb",
  });

  try {
    const selectJobsQuery = 'SELECT * FROM "Jobs"';
    const jobsResult = await connection.execute(selectJobsQuery);

    const insertOffersQuery = `
      INSERT INTO "Offers" ("JobID", "Company_ID")
      VALUES (:jobId, :companyId)
    `;

    for (const job of jobsResult.rows) {
      const industry = job[3];
      const selectCompaniesQuery = `
        SELECT "CompanyID" FROM "Company"
        WHERE "Industry" = :industry
      `;
      const companiesResult = await connection.execute(selectCompaniesQuery, [industry]);

      for (const companyRow of companiesResult.rows) {
        const companyId = companyRow[0];
        await connection.execute(insertOffersQuery, { jobId: job[0], companyId });
      }
    }
    await connection.commit(); 
  } catch (error) {
    console.error("Error inserting offers:", error);
  } finally {
    await connection.close();
  }
}

populateOffersTable();
