document.addEventListener('DOMContentLoaded', function () {

    const jobList = document.getElementById('jobList');
    const searchInput = document.getElementById('searchInput');
    const userID = document.body.getAttribute('data-user-id');
    let type = null ; 
    async function fetchType(){
        const typeRes = await fetch(`/fetchUsertype/${userID}`);
        const typejson = await typeRes.json();
        type = typejson.userType;
        console.log(type);  
    } 

    fetchType();
    async function fetchJobs(apiEndpoint) {
        try {
            const response = await fetch(apiEndpoint);
            const jobs = await response.json();
            renderJobs(jobs);

        } catch (error) {
            console.error('Error fetching higher paying jobs:', error);
        }
    }


    async function renderJobs(jobs) {
        let jobListHTML = '';
        jobs.forEach(job => {
            jobListHTML += `
            <li class ="job-list-item">
            <h3 class="job-title">${job.Title}</h3>
            <p class="job-info" data-type="Salary">Salary: $${job.Salary}</p>
            <p class="job-info">Category: ${job.Category}</p>
            <p class="job-info">JobId: ${job.JobID}</p>
            <div class="dropdown">
                <button class="toggle-dropdown-button">Offered by</button>
                <div class="dropdown-menu">
                    <select class="dropdown-select" data-ID="${job.JobID}">
                    </select>
                </div>
            </div>
            <i class ="fa fa-plus add-to-interests" data-job-id="${job.JobID}"></i>
        </li>
            `;
        });

        jobList.innerHTML = jobListHTML;
    }

    searchInput.addEventListener('input', () => {
        const searchTerm = searchInput.value.toLowerCase();
        const jobItems = jobList.querySelectorAll('li');

        jobItems.forEach(jobItem => {
            const jobTitle = jobItem.querySelector('h3').textContent.toLowerCase();
            if (jobTitle.includes(searchTerm)) {
                jobItem.style.display = 'block';
            } else {
                jobItem.style.display = 'none';
            }
        });
    });

    window.addEventListener('load', () => {
        fetchJobs('/fetchAllJobs');
    });


    document.getElementById('viewHigherPayingJobs').addEventListener('click', () => {
        if(!type) fetchType();
        if(type == 'Seeker'){
            fetchJobs('/fetchAllJobs'); 
        }
        else fetchJobs(`/fetchHigherPayingJobs/${userID}`);
    });

    document.getElementById('viewLowerPayingJobs').addEventListener('click', () => {
        if(!type) fetchType( ) ; 
        if( type == 'Seeker'){
            fetchJobs('/fetchAllJobs'); 
        }
        else fetchJobs(`/fetchLowerPayingJobs/${userID}`);
    });

    document.getElementById('viewAllJobs').addEventListener('click', () => {
        fetchJobs('/fetchAllJobs');
    });

    document.getElementById('MytypeofJobs').addEventListener('click', () => {
        if(!type) fetchType( ) ; 
        if( type == 'Seeker'){
            fetchJobs('/fetchAllJobs'); 
        }
        else fetchJobs(`/fecthMytypeOfJobs/${userID}`);
    });

    document.getElementById('Jobswithlowratings').addEventListener('click', ()=>{
        if(!type) fetchType( ) ; 
        if( type == 'Seeker'){
            fetchJobs('/fetchAllJobs'); 
        }
        else fetchJobs(`/fecthLowerRatedJobs`);
    });


    jobList.addEventListener('click', async (event) => {
        if (event.target.classList.contains('toggle-dropdown-button')) {
            const button = event.target;
            const dropdownMenu = button.nextElementSibling;
            const selectElement = dropdownMenu.querySelector('.dropdown-select');
            const jobID = selectElement.getAttribute('data-ID');
            try {
                const response = await fetch(`/fetchCompaniesbyJobID/${jobID}`);
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }

                const companies = await response.json();

                selectElement.innerHTML = '';

                companies.forEach(company => {
                    const option = document.createElement('option');
                    option.value = company.Name;
                    option.textContent = company.Name;
                    selectElement.appendChild(option);
                });

                dropdownMenu.style.display = 'block';
            } catch (error) {
                console.error('Error fetching companies:', error);
            }
        }
    });

    document.getElementById('sortOrder').addEventListener('change', () => {
        const selectedSortOrder = document.getElementById('sortOrder').value;
        const jobList = document.querySelectorAll('.job-list-item');

        const sortedList = Array.from(jobList).sort((a, b) => {
            const aSalary = parseFloat(a.querySelector('.job-info[data-type="Salary"]').textContent.replace('Salary: $', '').replace(/,/g, ''));
            const bSalary = parseFloat(b.querySelector('.job-info[data-type="Salary"]').textContent.replace('Salary: $', '').replace(/,/g, ''));

            if (selectedSortOrder === 'asc') {
                return aSalary - bSalary;
            } else {
                return bSalary - aSalary;
            }
        });

        const jobListContainer = document.getElementById('jobList');
        jobListContainer.innerHTML = '';
        sortedList.forEach(item => jobListContainer.appendChild(item));
    });

    jobList.addEventListener('click', async (event) => {
        if (event.target.classList.contains('add-to-interests')) {
            const button = event.target;
            const jobID = button.getAttribute('data-job-id');
            const userID = document.body.getAttribute('data-user-id');

            try {
                const response = await fetch('/addToInterests', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        ID_of_User: userID,
                        Wanted_JobID: jobID,
                    }),
                });

                if (response.ok) {
                    alert('Job added to interests successfully.');
                } else {
                    alert('Failed to add job to interests.');
                }
            } catch (error) {
                console.error('Error:', error);
                alert('An error occurred while adding the job to interests.');
            }
        }
    });

});


document.addEventListener('click', (event) => {
    const dropdownMenus = document.querySelectorAll('.dropdown-menu');

    dropdownMenus.forEach(dropdownMenu => {
        const button = dropdownMenu.previousElementSibling;
        if (event.target !== button && !dropdownMenu.contains(event.target)) {
            dropdownMenu.style.display = 'none';
        }
    });
});