const oracledb = require("oracledb"); 
const axios = require("axios"); 
const crypto = require('crypto'); 


async function run(query){
    const connection = await oracledb.getConnection({
        user: 'JOBATHON',
        password : '12345',
        connectString: 'localhost/orclpdb',
    }); 
    try{
        const results = await connection.execute(query);
        await connection.commit() ;
        return results;  
    }
    finally{
        await connection.close() ; //Always close connections.
    } 
}



async function update_user(){
    
    const query = `UPDATE "User" SET "ComID" = NULL WHERE "Type" = 'Seeker'`; 
    const res = await run(query);
}

update_user() ; 
