const notificationIcon = document.querySelector('.notification-icon');
const notificationDetails = document.querySelector('.notification-details');

notificationIcon.addEventListener('click', () => {
    notificationDetails.classList.toggle('active'); 
});

const jobOfferIcon = document.querySelector('.job-offer-icon');
const jobOfferDetails = document.querySelector('.job-offer-details');

jobOfferIcon.addEventListener('click', () => {
    jobOfferDetails.classList.toggle('active');
});

// Close the notification and job offer details when clicking outside of them




const hobbyIcon = document.querySelector('.hobby-icon');
const hobbyDetails = document.querySelector('.hobbyDetails');
const userID =document.body.getAttribute('data-user-ID'); 

hobbyIcon.addEventListener('click', async () => {
    hobbyDetails.classList.toggle('active');

    if (hobbyDetails.classList.contains('active')) {
        try {
            const response = await fetch(`/fetchHobbies/${userID}`);
            const hobbies = await response.json();

            const hobbiesList = document.createElement('ul');
            hobbies.forEach(hobby => {
                const hobbyItem = document.createElement('li');
                hobbyItem.textContent = hobby;
                hobbiesList.appendChild(hobbyItem);
            });

            hobbyDetails.innerHTML = '';
            hobbyDetails.appendChild(hobbiesList);
        } catch (error) {
            console.error('Error fetching hobbies:', error);
        }
    } else {
        hobbyDetails.innerHTML = '';
    }
});



///Adding new Hobby. 
///const addHobbyButton = document.getElementById('addHobbyButton');
// addHobbyButton.addEventListener('click', async () => {
//     const hobbyInput = document.getElementById('hobbyInput');
//     const newHobby = hobbyInput.value.trim();
//     if (newHobby) {
//         ///const userID = document.body.dataset.userId; // Access the user ID from the body's data attribute

//         try {
//             const response = await fetch('/addHobby', {
//                 method: 'POST',
//                 headers: {
//                     'Content-Type': 'application/json',
//                 },
//                 body: JSON.stringify({ userID, hobby: newHobby }),
//             });

//             if (response.ok) {
//                 console.log('Hobby added successfully');
//                 // Update the hobbies list (optional)
//             } else {
//                 console.error('Error adding hobby');
//             }
//         } catch (error) {
//             console.error('Error:', error);
//         }
//     }
// });

////Company Section.
const companyIcon = document.querySelector('.company-icon');
const companyDetails = document.querySelector('.company-details');
const ComID =document.body.getAttribute('data-user-ComID'); 

companyIcon.addEventListener('click', async () => {
    companyDetails.classList.toggle('active');

    if (companyDetails.classList.contains('active')) {        
        try {
            const response = await fetch(`/fetchCompany/${ComID}`);
            const company = await response.json();

            companyDetails.innerHTML = `
                <p><strong>Company Name:</strong> ${company.Name}</p>
                <p><strong>CEO:</strong> ${company.CEO}</p>
                <p><strong>Industry:</strong> ${company.Industry}</p>
                <p><strong>Headquarter:</strong> ${company.Origin}</p>
            `;
        } catch (error) {
            console.error('Error fetching company details:', error);
        }
    } else {
        companyDetails.innerHTML = '';
    }
});


////review section:
const reviewIcon = document.querySelector('.review-icon');
const reviewDetails = document.querySelector('.review-details');

function generateStars(rating) {
    const starIcons = '<i class="fa fa-star"></i>'.repeat(rating);
    const emptyStars = '<i class="fa fa-star-o"></i>'.repeat(5 - rating);
    return starIcons + emptyStars;
}

async function fetchCompanyDetails(companyID) {
    try {
        const res = await fetch(`/fetchCompany/${companyID}`);
        const companyDetails = await res.json();
        return companyDetails;
    } catch (error) {
        console.error('Error fetching company details:', error);
        return null; // Return null or an error indicator as needed
    }
}

reviewIcon.addEventListener('mouseenter', async () => {
    try {
        const response = await fetch(`/fetchReviews/${userID}`);
        const reviews = await response.json();

        const reviewsList = document.createElement('ul');

        for (const review of reviews) {
            const companydetails = await fetchCompanyDetails(review.ReviewedCompanyID);

            const reviewItem = document.createElement('li');
            const stars = generateStars(review.Review);
            console.log(stars); 
            reviewItem.innerHTML = `Reviewed Company: ${companydetails ? companydetails.Name : 'N/A'} as ${stars}`;
            reviewsList.appendChild(reviewItem);
        }

        reviewDetails.innerHTML = '';
        reviewDetails.appendChild(reviewsList);
        reviewDetails.classList.add('active');
    } catch (error) {
        console.error('Error fetching reviews:', error);
    }
});



reviewIcon.addEventListener('mouseleave', () => {
    reviewDetails.classList.remove('active');
    reviewDetails.innerHTML = '';
});




document.addEventListener('click', (event) => {
    if (!notificationIcon.contains(event.target)) {
        notificationDetails.classList.remove('active');
    }
    if (!jobOfferIcon.contains(event.target)) {
        jobOfferDetails.classList.remove('active');
    }
    if (!companyIcon.contains(event.target)) {
        companyDetails.classList.remove('active');
    }
    if (!hobbyIcon.contains(event.target)) { 
        hobbyDetails.classList.remove('active');
    }
    if(!reviewIcon.contains(event.target)){
        reviewDetails.classList.remove('active'); 
    }
});



/////modal-resume section:
const openResumeModal = document.getElementById('openResumeModal');
const resumeModal = document.getElementById('resumeModal');
const closeResumeModal = document.getElementById('closeResumeModal');
const resumeTextarea = document.getElementById('resumeTextarea');
const saveResumeButton = document.getElementById('saveResume');
const resumeContentElement = document.getElementById('resumeContent'); // Update this selector based on your actual HTML

// Open the modal when the button is clicked
openResumeModal.addEventListener('click', () => {
  resumeTextarea.value = resumeContentElement.textContent; 
  resumeModal.style.display = 'block';
});

// Close the modal when the close button is clicked
closeResumeModal.addEventListener('click', () => {
  resumeModal.style.display = 'none';
});

// Save the resume content
saveResumeButton.addEventListener('click', () => {
    console.log(resumeContentElement) ; 
    console.log(resumeTextarea.value); 
  resumeContentElement.textContent = resumeTextarea.value; // Update the content on the page
  resumeModal.style.display = 'none';
});


////Job details modal: 
document.addEventListener('DOMContentLoaded', () => {
    const jobDetailsButton = document.querySelector('.job-details-button');
    const jobDetailsModal = document.getElementById('jobDetailsModal');
    const jobDetailsContent = document.getElementById('jobDetailsContent');
    const closeJobDetails = document.querySelector('.close1'); 
  
    jobDetailsButton.addEventListener('click', async () => {
      try {
        const response = await fetch(`/fetchJobDetails/${userID}`);
        const jobDetails = await response.json();
  
        if (Array.isArray(jobDetails)) {
          let content = '<ul>';
          jobDetails.forEach(job => {
            content += `<li>Job Title: ${job.Title}, Salary: ${job.Salary}</li>`;
          });
          content += '</ul>';
  
          jobDetailsContent.innerHTML = content;
          jobDetailsModal.style.display = 'block';
        } else {
          jobDetailsContent.innerHTML = 'No job details available.';
          jobDetailsModal.style.display = 'block';
        }
      } catch (error) {
        console.error('Error fetching job details:', error);
      }
    });
  
    closeJobDetails.addEventListener('click', () => {
      jobDetailsModal.style.display = 'none';
    });
  });
  

