document.addEventListener("DOMContentLoaded", function (event) {

    const showNavbar = (toggleId, navId, bodyId, headerId) => {
        const toggle = document.getElementById(toggleId),
            nav = document.getElementById(navId),
            bodypd = document.getElementById(bodyId),
            headerpd = document.getElementById(headerId)


        // Validate that all variables exist
        if (toggle && nav && bodypd && headerpd) {
            toggle.addEventListener('click', () => {
                // show navbar
                nav.classList.toggle('show')
                // change icon
                toggle.classList.toggle('bx-x')
                // add padding to body
                bodypd.classList.toggle('body-pd')
                // add padding to header
                headerpd.classList.toggle('body-pd')
            })
        }
    }

    showNavbar('header-toggle', 'nav-bar', 'body-pd', 'header')

    /*===== LINK ACTIVE =====*/
    const linkColor = document.querySelectorAll('.nav_link')

    function colorLink() {
        if (linkColor) {
            linkColor.forEach(l => l.classList.remove('active'))
            this.classList.add('active')
        }
    }
    linkColor.forEach(l => l.addEventListener('click', colorLink))
});


document.addEventListener("DOMContentLoaded", function () {
    const fadeChangeContent = (elementId, newContent) => {
        const element = document.getElementById(elementId);
        element.style.opacity = 0;

        setTimeout(() => {
            element.innerHTML = newContent;
            element.style.opacity = 1;
        }, 300);
    };

    const loadDashboardContent = async () => {
        sectionIDs = ['similar-users-container', 'company-content', 'jobdetails-content', 'view-jobs-content','messages-content'];
        hideSections(sectionIDs);
        const dashboardContent = document.getElementById('dashboard-content');
        const age = document.body.getAttribute('data-user-age');
        const gender = document.body.getAttribute('data-user-gender');
        const Country = document.body.getAttribute('data-user-country');
        const phone = document.body.getAttribute('data-user-phone');
        const firstName = document.body.getAttribute('firstName');
        const lastName = document.body.getAttribute('lastName');
        const city = document.body.getAttribute('city');
        const ComID = document.body.getAttribute('data-user-ComID');
        const Photo = document.body.getAttribute('data-user-Photo');

        const userInformationHTML = `
        <div class="user-info" style="display: flex; align-items: center;">
        <div style="flex: 1;">
            <h1><strong>User Information</strong></h1>
            <p><strong>Name:</strong> ${firstName} ${lastName}</p>
            <p><strong>Age:</strong> ${age}</p>
            <p><strong>Gender:</strong> ${gender}</p>
            <p><strong>City:</strong> ${city}</p>
            <p><strong>Country:</strong> ${Country}</p>
            <p><strong>Phone:</strong> ${phone}</p>
        </div>
        <div class="user-photo" style="margin-left: 20px;">
            <img src="${Photo}" alt="User Photo" style="border-radius: 50%; width: 100px; height: 100px;">
        </div>
    </div>
                `;
        dashboardContent.style.display = 'block';
        dashboardContent.innerHTML = userInformationHTML;
    };
    const dashboardLink = document.querySelector('.nav_link.active');
    if (dashboardLink) {
        dashboardLink.addEventListener('click', loadDashboardContent);
    }

    const loadCompanyDetails = async () => {
        try {
            sectionIDs = ['dashboard-content', 'similar-users-container', 'view-jobs-content','messages-content'];
            hideSections(sectionIDs);
            const ComID = document.body.getAttribute('data-user-ComID');
            const type = document.body.getAttribute('data-user-type');
            if (type == 'Seeker') {
                const details = `<p><strong>Not currently working. Explore jobs!</strong></p>`;
                dashboardContent.innerHTML = details;
            }
            else {
                const userID = document.body.getAttribute('data-user-ID');
                const jobdetails = document.getElementById('jobdetails-content');
                const companycontent = document.getElementById('company-content');
                const res = await fetch(`/fetchJobDetails2/${userID}`);
                const jobData = await res.json();
                const response = await fetch(`/fetchCompany/${ComID}`);
                const companyData = await response.json();
                const companyDetailsHTML = `
                <div class="company-details">
                <h1><strong>Current Workplace</strong></h1>
                <p></p> 
                    <p><strong>Name:</strong> ${companyData.Name}</p>
                    <p><strong>Main Branch: </strong>${companyData.Main_Branch}</p>
                    <p><strong>Location: </strong> ${companyData.Origin}</p>
                    <p><strong>ID: </strong> ${companyData.CompanyID} </p>
                    <p><strong>CEO: </strong> ${companyData.CEO} </p>
                    <p><strong>Industry: </strong> ${companyData.Industry} </p>
                </div>
            `;

                const jobhtml = `
            <div class ="job-details">
            <p></p>
            <h1><strong>Current Job </strong></h1>
            <p><strong>Name:</strong>${jobData.Title}</p>
            <p><strong>Salary :</strong>${jobData.Salary}</p>
            <p><strong>Job ID:</strong> ${jobData.JobID}</p>
            `;
                companycontent.style.display = 'block';
                companycontent.innerHTML = companyDetailsHTML;
                jobdetails.style.display = 'block';
                jobdetails.innerHTML = jobhtml;
            }
        } catch (error) {
            console.error('Error fetching company details:', error);
        }
    };

    const companyDetailsLink = document.getElementById('company-details-link');
    if (companyDetailsLink) {
        companyDetailsLink.addEventListener('click', loadCompanyDetails);
    }

    const loadOthersLink = async () => {
        sectionIDs = ['dashboard-content', 'company-content', 'jobdetails-content', 'view-jobs-content', 'messages-content'];
        hideSections(sectionIDs);
        const userID = document.body.getAttribute('data-user-ID');
        try {
            const res = await fetch(`/fetchSimilarUsers/${userID}`);
            const ans = await res.json();
            const similarUsersList = document.getElementById('similar-users-list');
            similarUsersList.innerHTML = '';
            ans.forEach((user) => {
                const userListItem = document.createElement('li');
                userListItem.innerHTML = `
                <img src="${user.Photo}" alt="User Photo">
                <div>
                    <p class="user-info"><strong>First Name:</strong> ${user.firstName}</p>
                    <p class="user-info2"><strong>Last Name:</strong> ${user.lastName}</p>  
                    <p><strong>Phone:</strong> ${user.Phone}</p>
                    <p><strong>Gender:</strong> ${user.Gender}</p>
                    <p><strong>Country:</strong> ${user.Country} </p>
                </div>
            `;
                similarUsersList.appendChild(userListItem);
            }
            );
            const similarUsersContainer = document.getElementById('similar-users-container');
            similarUsersContainer.style.display = 'block';
        }
        catch (error) {
            console.error('Error fetching company details:', error);
        }
    }
    const otherdetails = document.getElementById('others-details-link');
    if (otherdetails) {
        otherdetails.addEventListener('click', loadOthersLink);
    }

    const searchInput = document.getElementById('searchInput');
    const similarUsersList = document.getElementById('similar-users-list');

    searchInput.addEventListener('input', () => {
        const searchTerm = searchInput.value.toLowerCase();
        const userItems = similarUsersList.querySelectorAll('li');

        userItems.forEach(userItem => {
            const userName = userItem.querySelector('.user-info').textContent.toLowerCase();///firstName.
            const userName2 = userItem.querySelector('.user-info2').textContent.toLowerCase();///lastName. 
            if (userName.includes(searchTerm) || (userName2).includes(searchTerm)) {
                userItem.style.display = 'block';
            } else {
                userItem.style.display = 'none';
            }
        });
    });

    const loadAllJobs = async () => {
        sectionIDs = ['dashboard-content', 'company-content', 'jobdetails-content', 'similar-users-container', 'messages-content'];
        hideSections(sectionIDs);
        const res = await fetch(`/fetchAllJobs`);
        const ans = await res.json();
        const JobHtml1 = document.getElementById('Jobs_List1');
        const JobHtml2 = document.getElementById('Jobs_List2');
        JobHtml1.innerHTML = '';
        JobHtml2.innerHTML = '';
        let cnt = 0;
        ans.forEach((Job) => {
            const JobListItem = document.createElement('li');
            JobListItem.classList.add('job-list-item'); // Add a class for styling

            JobListItem.innerHTML = `
                <div class="job-info">
                    <h3><i class="fa fa-briefcase job-icon"></i>${Job.Title}</h3>
                    <p class="job-salary"><strong>Salary:</strong> $${Job.Salary}</p>
                    <p class ="job-category"><strong>Category:</strong>${Job.Category}</p>
                    <button class="add-interest-button" data-job-id="${Job.JobID}"><i class="fa fa-plus"></i></button>
                </div>
            `;

            if (cnt % 2 === 0) {
                JobHtml1.appendChild(JobListItem);
            } else {
                JobHtml2.appendChild(JobListItem);
            }
            cnt++;
        });

        const viewJobs = document.getElementById('view-jobs-content');
        viewJobs.style.display = 'block';
        const addInterestButtons = document.querySelectorAll('.add-interest-button');
        addInterestButtons.forEach(button => {
            button.addEventListener('click', async () => {
                const jobId = button.getAttribute('data-job-id');
                const userId = document.body.getAttribute('data-user-ID');
                ///for debugging.
                // console.log(JSON.stringify({
                //     ID_of_User: userId,
                //     JobID: jobId
                // }));

                try {
                    const response = await fetch('/addToInterests', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            ID_of_User: userId,
                            Wanted_JobID: jobId
                        })
                    });

                    if (response.ok) {
                        alert('Job added to interests successfully!');
                    } else {
                        alert('Failed to add job to interests.');
                    }
                } catch (error) {
                    console.error('Error:', error);
                    alert('An error occurred while adding job to interests.');
                }
            });
        });
    };

    const viewJobsSection = document.getElementById('All-Jobs-link');
    if (viewJobsSection) {
        viewJobsSection.addEventListener('click', loadAllJobs);
    }



    const messagesLink = document.getElementById('messages-link');
    const messagesContent = document.getElementById('messages-content');

    messagesLink.addEventListener('click', () => {
        sectionIDs = ['dashboard-content', 'company-content', 'jobdetails-content', 'similar-users-container', 'view-jobs-content'];
        hideSections(sectionIDs);
        if (messagesContent.style.display === 'none') {
            messagesContent.style.display = 'block';
        } else {
            messagesContent.style.display = 'none';
        }
    });
    function sendMessage() {
        const messageInput = document.getElementById('message-input');
        const message = messageInput.value.trim();

        if (message !== '') {
            // Emit the message to the server
            socket.emit('chat message', message);
            messageInput.value = '';
        }
    }
    const socket = io('http://localhost:3000');
    socket.on('chat message', (message) => {
        const messageList = document.getElementById('message-list');
        const messageItem = document.createElement('li');
        messageItem.textContent = message;
        messageList.appendChild(messageItem);
    });
    const sendButton = document.getElementById('send-button');
    sendButton.addEventListener('click', sendMessage);

    // Fetch and display existing messages
    fetch('/api/messages')
        .then((response) => response.json())
        .then((data) => {
            const messageList = document.getElementById('message-list');
            data.forEach((message) => {
                const messageItem = document.createElement('li');
                messageItem.textContent = message;
                messageList.appendChild(messageItem);
            });
        });

    function hideSections(sectionIds) {
        sectionIds.forEach(id => {
            const section = document.getElementById(id);
            if (section) {
                section.style.display = 'none';
            }
        });
        const welcome = document.getElementById('Welcome');
        welcome.style.display = "none";
    }


});

