const oracledb = require("oracledb");
const jobsData = require("./Jobs_Info");

async function populateJobsTable() {
  const connection = await oracledb.getConnection({
    user: "JOBATHON",
    password: "12345",
    connectString: "localhost/orclpdb",
  });

  try {
    const insertQuery = `
      INSERT INTO "Jobs" ("JobID", "Title", "Job_Info", "Salary", "CompanyID", "Sector")
      VALUES (:jobID, :title, :job_info, :salary, :companyID, :sector)
    `;

    for (const job of jobsData) {
      const bindParams = {
        jobID: job.jobID,
        title: job.title,
        job_info: job.job_info,
        salary: job.salary,
        companyID: job.companyID,
        sector: job.sector,
      };

      await connection.execute(insertQuery, bindParams, { autoCommit: true });
      console.log(`Inserted job with JobID ${job.jobID}`);
    }
  } catch (error) {
    console.error("Error inserting jobs:", error);
  } finally {
    await connection.close();
  }
}

populateJobsTable();
