const oracledb = require("oracledb"); 
const axios = require("axios"); 
const crypto = require('crypto'); 


async function run(query){
    const connection = await oracledb.getConnection({
        user: 'JOBATHON',
        password : '12345',
        connectString: 'localhost/orclpdb',
    }); 
    try{
        const results = await connection.execute(query);
        await connection.commit() ;
        return results;  
    }
    finally{
        await connection.close() ; //Always close connections.
    } 
}
async function updateUserCompany() {
    const updateQuery = `
        UPDATE "User" SET "ComID" = FLOOR(DBMS_RANDOM.VALUE(1, 42))
        WHERE "Type" <> 'Seeker'
    `;

    try {
        const result = await run(updateQuery);
        console.log('Here');
    } catch (error) {
        console.error('Error:', error);
        throw error;
    }
}

updateUserCompany(); 