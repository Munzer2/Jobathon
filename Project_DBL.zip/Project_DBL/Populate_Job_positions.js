const oracledb = require("oracledb");

async function run(query, binds = []) {
  const connection = await oracledb.getConnection({
    user: "JOBATHON",
    password: "12345",
    connectString: "localhost/orclpdb",
  });

  try {
    const options = { autoCommit: true, binds: binds };
    const result = await connection.execute(query, binds, options);
    return result;
  } finally {
    await connection.close();
  }
}

async function populateJobPositionsTable() {
  const selectUsersQuery = `SELECT * FROM "User" WHERE "Type" != 'Seeker'`;
  const usersResult = await run(selectUsersQuery);

  const insertJobPositionsQuery = `
    INSERT INTO "JobPositions" ("CurrentJobID","WorkerID")
    VALUES (:jobId,:userId)
  `;

  const totalJobs = 80;

  for (const user of usersResult.rows) {
    const randomJobId = Math.floor(Math.random() * totalJobs) + 1;

    const binds = {
      jobId: randomJobId, 
      userId: user[0],
    };

    await run(insertJobPositionsQuery, binds);
    console.log(`Inserted job position for UserID ${user[0]} with JobID ${randomJobId}`);
  }
}

populateJobPositionsTable();
