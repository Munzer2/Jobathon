
const jobList = document.getElementById('jobList');
const searchInput = document.getElementById('searchInput');
const filterInput = document.getElementById('filterInput');
const userID = document.body.getAttribute('data-user-id');

async function fetchAndDisplayHigherPayingJobs(userID) {
    try {
        const response = await fetch(`/fetchHigherPayingJobs/${userID}`);
        const higherPayingJobs = await response.json();

        let jobListHTML = '';
        higherPayingJobs.forEach(job => {
            jobListHTML += `
            <li style="display: inline-block; width: 70%; margin: 10px; padding: 15px; background-color: white; border-radius: 5px; border: 2px solid #666; color: black;">
            <h3 class="job-title" style="font-size: 20px; margin: 0;">${job.Title}</h3>
            <p class="job-info" style="margin-top: 5px; font-size: 14px;">Salary: ${job.Salary}</p>
            <p class="job-info" style="font-size: 14px;">Sector: ${job.Sector}</p>
            <p class="job-info" style="font-size: 14px;">JobID: ${job.JobID}</p>
        </li>
            `;
        });

        jobList.innerHTML = jobListHTML;
    } catch (error) {
        console.error('Error fetching higher paying jobs:', error);
    }
}

searchInput.addEventListener('input', () => {
    const searchTerm = searchInput.value.toLowerCase();
    const jobItems = jobList.querySelectorAll('li');

    jobItems.forEach(jobItem => {
        const jobTitle = jobItem.querySelector('h3').textContent.toLowerCase();
        if (jobTitle.includes(searchTerm)) {
            jobItem.style.display = 'block';
        } else {
            jobItem.style.display = 'none';
        }
    });
});

filterInput.addEventListener('input', () => {
    const filterTerm = filterInput.value.toLowerCase();
    const jobItems = jobList.querySelectorAll('li');

    jobItems.forEach(jobItem => {
        const jobSalary = jobItem.querySelector('p:nth-child(2)').textContent.toLowerCase();
        if (jobSalary.includes(filterTerm)) {
            jobItem.style.display = 'block';
        } else {
            jobItem.style.display = 'none';
        }
    });
});
fetchAndDisplayHigherPayingJobs(userID);
