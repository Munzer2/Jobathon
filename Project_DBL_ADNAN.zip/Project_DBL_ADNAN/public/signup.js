document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('signup-Form');
    
    loginForm.addEventListener('submit', async (event) => {
        event.preventDefault();

        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value; 
        const firstname = document.getElementById('firstname').value; 
        const lastname = document.getElementById('lastname').value;
        const password_confirm = document.getElementById('password-confirm').value; 
        
        if(password===password_confirm){
            const response = await fetch(`/signUpCheck?username=${username}&password=${password}`);
            const data = await response.json();
    
            if (data.success) {

                console.log("sucess");
                console.log(username);
                console.log(firstname);
                console.log(lastname);
                console.log(password);
                
                try {
                    const response = await fetch('/signUpInsert', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({

                            ID_of_User: username,
                            firstname : firstname,
                            lastname: lastname,
                            password: password
                        })
                    });

                    if (response.ok) {
                        alert(`${username} you have succefully signed up. Welcome to Jobathon`);
                    } else {
                        alert('sign up failed');
                    }
                } catch (error) {
                    console.error('Error:', error);
                    alert('An error occurred while adding job to interests.');
                }


                // window.location.href = `/user/${username}`; 
            } else {
                alert('User name already Exists. Please try a different username .');
            }


        }
        else{
            alert('Confirm password field doesnt match with password.');
        }


    });
});

